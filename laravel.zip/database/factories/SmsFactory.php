<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Sms;
use Faker\Generator as Faker;

$factory->define(Sms::class, function (Faker $faker) {
    return [
        //
    ];
});
