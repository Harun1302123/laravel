<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable=['session', 'class', 'group', 'roll', 'name','f_name','m_name', 'address', 'mobile'];
}
