<?php

namespace App\Http\Controllers;

use App\Sms;
use Illuminate\Http\Request;
use Auth;
//define('SMS_APIKEY', 'C20029585c447bafaba5c4.02415382');

class SmsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function message(Request $request)
    {
        $message = 'Hi...';
        //$message = $request->input('message');
        $mobile = $request->input('mobile');
        $encodeMessage = urlencode($message);
        $authkey = '';
        $senderId = '';
        $route = 4;
        $postData = $request->all();
        $mobileNumber = implode('', $postData['mobile']);
        $arr = str_split($mobileNumber, '11');
        $mobiles = implode(",", $arr);
        //print_r($mobiles);
        //exit();
        $data = array(
            'authkey' => $authkey,
            'mobiles' => $mobiles,
            'message' => $encodeMessage,
            'sender' => $senderId,
            'route' => $route
        );
        $url = "";
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData
        ));

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        //get response
        $output = curl_exec($ch);

        //Print error if any
        if(curl_errno($ch)){
            echo 'error:'.curl_error($ch);
        }
        curl_close($ch);
        //return redirect()->back();
    }

}

    
