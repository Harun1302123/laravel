<?php

namespace App\Http\Controllers;

use App\Student;
use Illuminate\Http\Request;
use Auth;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $students = Student::paginate(100);
        return view('sms', compact('students'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate(request(),[
            'name'=>'required',
        ]);
        Student::create($request->all());
        return redirect()->back()->with('msg', 'Inserted');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(Student $student)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit(Student $student)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $students=Student::findOrFail($id);
        $students->update($request->all());
        return redirect()->back()->with('msg', 'Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $students=Student::findOrFail($id);
        $students->delete();
        return redirect()->back()->with('msg','Delete');
    }

    public function sms()
    {
        return view('Student.sms');
        /*echo "<script>window.location.href = 'Student.index'</script>";*/
    }

    public function message(Request $request)
    {
        //$message = 'Hi...';
        $message = $request->input('message');
        $mobile = $request->input('mobile');
        //$mobile = '01776967480';
        $encodeMessage = urlencode($message);
        $authkey = 'C20029585c447bafaba5c4.02415382';
        $senderId = '8801847169884';
        //$route = 4;
        $postData = $request->all();
        //print_r($postData);
        //exit();
        //$mobileNumber = implode(' ', $postData['mobile']);
        //$arr = str_split($mobileNumber, '12');
        //$mobiles = implode(",", $arr);
        
        $data = array(
            'authkey' => $authkey,
            //'mobiles' => $mobiles,
            'mobile' => $mobile,
            'message' => $encodeMessage,
            'sender' => $senderId,
            //'route' => $route
        );
        $url = "http://esms.dianahost.com/smsapi?";
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData
        ));

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        //get response
        $output = curl_exec($ch);

        //Print error if any
        if(curl_errno($ch)){
            echo 'error:'.curl_error($ch);
        }
        curl_close($ch);
        return redirect()->back()->with('response','Mesage Sent');
    }
}
