<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Auth::routes(['register' => false]);



Route::group(['middleware' => ['auth']], function() {

		
		Route::resource('datas','SchoolController');
});
*/


Route::get('/', function () {
    return view('welcome');
});
Route::get('/att', function () {
    return view('attdence');
});
Route::get('/at', function () {
    return view('Student.attendence');
});
/*Route::get('/sms', function () {
    return view('Student.sms');
});*/

Route::get('/t', function () {
    return view('template');
});
/*Route::get('/m', function () {
    return view('sms');
});*/
Auth::routes();

Route::post('/msg', 'StudentController@message');
Route::get('/m', 'StudentController@index');
/*Route::get('/st', 'StudentController@index');*/
Route::post('/a_st', 'StudentController@store');
Route::delete('/del/{id}', 'StudentController@destroy');
Route::put('/edit/{id}', 'StudentController@update');
Route::post('/sms', 'StudentController@sms');
/*Route::get('/sms', 'StudentController@sms');*/

Route::get('/school', 'SchoolController@index');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
