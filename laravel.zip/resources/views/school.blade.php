<!DOCTYPE html>
<html>
<head>
  <title>data</title>
  <!--  bootstrap 4 link  -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"> 
  <!--  data table link  -->
  <link rel="stylesheet" href="http://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <!--  font-awesome link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--  style -->
  <link rel="stylesheet" href="../css/style.css">
  <!--  js link  -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
  <!--  data table js link  -->
  <script src="http://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript">
    $(document).ready( function () {
        $('#myTable').DataTable();
    } );
  </script>
</head>
<body>
	<table id="myTable">
		<tr>
			<td style="border: 1px solid;">Id</td>
			<td style="border: 1px solid;">Name</td>
			<td style="border: 1px solid;">Address</td>
		</tr>
		@foreach($datas as $data)
		<tr>
			<td style="border: 1px solid;">{{$data->id}}</td>
			<td style="border: 1px solid;">{{$data->name}}</td>
			<td style="border: 1px solid;">{{$data->address}}</td>
			
		</tr>
		@endforeach
	</table>

</body>
</html>