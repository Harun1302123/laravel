@extends('layouts.header_layout')

@section('content')
			<div class="content-wrapper">
                <div class="content"> <!-- content start -->
                	<div class="col-sm-12">
                		<div class="row">
		                    <div class="col-sm-12" id="gridview">
		                    	<div class="panel-heading">
		                    		@if(session('response'))
		                    			<div class="alert alert-success">
		                    				{{ session('response') }} 
		                    			</div>
		                    		@endif
		                    	</div>
		                    	<form action="{{action('StudentController@message')}}" method="POST">
		                    		{{csrf_field()}}
			                        <div class="panel panel-default" id="attendancediv" style="">
			                            <div class="panel-heading">
			                                <h4 class="panel-title">Attendance </h4>
			                            </div>
			                            <div class="form-group">
			                            	<input type="text" name="massage" placeholder="Message" class="form-control">
			                            </div>
			                            <div class="table-responsive">
			                                <table class="table responsive table-bordered table-striped" id="studentattendence">
			                                    <thead>
			                                        <tr>
			                                            <th data-hide="phone" class="footable-last-column" width="15%"><input type="checkbox" id="checkall">&nbsp;&nbsp;&nbsp;Check all</th>
			                                            <th data-hide="phone,tablet" width="10%">Roll No.</th>
			                                            <th data-hide="phone,tablet" width="15%">ID</th>
			                                            <th data-hide="phone,tablet" width="30%">Student Name</th>
			                                            <th data-hide="phone,tablet" width="15%">Class</th>
														<th data-hide="phone" class="footable-last-column" width="15%"><input type="checkbox" id="checkstatus" class="checkbox1">&nbsp;&nbsp;&nbsp;Check all</th>
			                                        </tr>
			                                    </thead>
			                                    <tbody>
			                                    	@foreach($students as $student)
			                                    	<tr>
			                                    		<td data-id="220">
			                                    			<input type="checkbox" name="mobile" value="{{$student->mobile}}" class="checkbox">
			                                    		</td>
			                                    		<td>101</td>
			                                    		<td>1</td>
			                                    		<td>{{$student->name}}</td>
			                                    		<td>8</td>
			                                    		<td>
			                                    			<input type="checkbox" name="attendence1" class="checkbox1">
			                                    		</td>
			                                    	</tr>
			                                    	@endforeach
			                                    </tbody>
			                                </table>
			                            </div>
			                        </div>
			                        <input type="submit" name="sms" value="Message" class="btn btn-info">
		                        </form>
		                    </div>
		                </div>
                	</div>

		</div> <!-- header_layout close -->
    </div>
@endsection