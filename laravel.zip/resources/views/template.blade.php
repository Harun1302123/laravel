@extends('layouts.header_layout')

@section('content')

			<div class="content-wrapper">
                <div class="content"> <!-- content start -->
                	   
		</div> <!-- header_layout close -->
    </div>
@endsection