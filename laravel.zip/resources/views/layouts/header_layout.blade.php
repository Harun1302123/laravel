<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>School </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="https://web-school.in/try-demo/" />
    <link rel="stylesheet" type="text/css" href="{{ asset('css/styles.css') }}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('css/jquery-ui.css') }}" />

<script type="text/javascript" src="{{ asset('js/jquery.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/app.js') }}"></script>

    <!-- Global stylesheets -->
    <link href="{{ asset('css/roboto.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/icomoon.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/core.min.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/grid.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/components.min.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/colors.min.css') }}" rel="stylesheet" type="text/css">
    <!-- <link href="{{ asset('css/fullcalendar.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/fullcalendar.print.css') }}" rel="stylesheet" type="text/css" media="print">
    <link href="{{ asset('css/datepicker.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/bootstrap-timepicker.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/progress_tracker.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/glyph.css') }}" rel="stylesheet" type="text/css"> -->
    <link href="{{ asset('css/style.css') }}" rel="stylesheet" type="text/css">

    

   
</head>

<body class="pace-done">
    <div class="navbar navbar-default header-highlight">
        <div class="navbar-header">
            <a class="navbar-brand" href="#" style="color: #f5f5f5 !important;">
                <i class="fa fa-address-card"></i>
            </a>
            <ul class="nav navbar-nav visible-xs-block">
                <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="fa fa-retweet"></i></a></li>
                <li><a class="sidebar-mobile-main-toggle"><i class="fa fa-bars"></i></a></li>
            </ul>
        </div>

        <div class="navbar-collapse collapse" id="navbar-mobile">
            <ul class="nav navbar-nav">
                <li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="fa fa-bars"></i></a></li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-sticky-note"></i>
                        <span class="visible-xs-inline-block position-right">Updates</span>
                        <span class="badge bg-warning-400">!</span>
                    </a>
                    <div class="dropdown-menu dropdown-content">
                        <div class="dropdown-content-heading">Updates</div>
                        <ul class="media-list dropdown-content-body width-350">
                            <li class="media">
                                <div class="media-left">
                                    <a href="#" class="btn border-brown-800 text-brown-800 btn-flat btn-rounded btn-icon btn-sm"><i class="fa fa-edit"></i></a>
                                </div>
                                <div class="media-body">
                                   <a href="/index.php/leave/leaveapplication/approve"><font color="#4E342E">Leave Approvals</font></a><br> 
                                     <div class="media-annotation"> You have 2 pending leave approval(s)</div>
                                </div>
                            </li> 
                        </ul>
                    </div>
                </li>
            </ul>
                                <p class="navbar-text"><span class="label bg-info">Academic Year: ( 2006 - 2017 )</span></p>
                            <ul class="nav navbar-nav navbar-right">
                                        <form class="navbar-form navbar-left" action="/index.php/core/institution/search" target="_blank" method="POST">
                        <div class="form-group">
                            <input placeholder="Search..." class="form-control" id="user" type="text" value="" name="user" /><input id="hidden-field" name="output" type="hidden" value="" />                            </div>
                        <button type="submit" class="btn btn-default" onclick="return autocompletesearch()"><i class="fa fa-search"></i></button>
                    </form>
                                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-comments"></i>
                        <span class="visible-xs-inline-block position-right">Messages</span>
                                                    <span class="badge bg-warning-400" id="envelope">0</span>
                    </a>
                    <div class="dropdown-menu dropdown-content width-350">
                        <div class="dropdown-content-heading"> Messages </div>
                        <ul class="media-list dropdown-content-body">
                                                        </ul>
                        <div class="dropdown-content-footer">
                                                                <a href="/index.php/core/email/email" data-popup="tooltip" title="All messages"><i class="icon-menu display-block"></i></a>
                                                        </div>
                    </div>
                </li>
                                        <li class="dropdown dropdown-user">
                                                        <a class="dropdown-toggle" data-toggle="dropdown">
                                <img src="/banner/01062018035544.jpg" alt="">
                                <span>Andre  Rudolph</span>
                                <i class="caret"></i>
                            </a>
                                                    <ul class="dropdown-menu">
                                                                <li><a href="/index.php/core/institution/profile"><i class="icon-user"></i>Profile</a></li>
                                                            <li><a href="/index.php/user/logout" onclick="signOut();"><i class="icon-switch2"></i>Log Out</a></li>

                        </ul>
                    </li>
                                    </ul>
        </div>
    </div>



    <div class="page-container">
        <div class="page-content">
            <div class="sidebar sidebar-main">
                <div class="sidebar-content">
                    <div class="sidebar-user">
                        <div class="category-content">
                            <div class="media">
                                <a href="#" class="media-left"><i class="fa fa-bars"></i></a>
                                <div class="media-body">
                                    <span class="media-heading text-semibold">Demo School</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="sidebar-category sidebar-category-visible">
                        <div class="category-content no-padding">
                            <ul class="navigation navigation-main navigation-accordion">
                                <li>
                                    <a href="#"><i class="fa fa-home"></i><span>Dashboard</span></a>
                                    <ul data-index="0" style="display: none;">
                                        <li><a href="/att">Dashboard</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-cog"></i><span>Settings</span></a>
                                    <ul>
                                        <li><a href="institution/create">Institution Details</a></li>
                                        <li><a href="academic/create">Academic Details</a></li>
                                        <li><a href="site/import">Student Import</a></li>
                                        <li><a href="site/employeeimport">Employee Import</a></li>
                                        <li><a href="application/admin">Applicant List</a></li>
                                         <li><a href="onlineemployeedetails/admin">Employee Application</a></li>
                                        <li><a href="/index.php/core/studentcaste/create">Caste And Religion</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-users"></i><span>Academic</span></a>
                                    <ul>
                                        <li>
                                            <a href="#">Course & Batch</a>
                                            <ul>
                                                <li><a href="/index.php/core/course/create">Course</a></li>
                                                <li><a href="/index.php/core/batch/create">Batch</a></li>
                                                <li><a href="/index.php/core/classteacherallocation/create">Class teacher Allocation</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Subjects</a>
                                            <ul>
                                                <li><a href="/index.php/core/subject/create">Subjects</a></li>
                                                <li><a href="/index.php/core/subject/assignsubject">Assign Subjects</a></li>
                                                <li><a href="/index.php/core/subjectallocation/create">Subject Allocation</a></li>
                                                <li><a href="/index.php/core/subject/electivesubjects">Elective Subject</a></li>
                                                <li><a href="/index.php/core/subjectallocation/subjectallocationimport">Subject Allocation Import</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Lesson Planning</a>
                                            <ul>
                                                <li><a href="/index.php/core/lessonplanning/create">Lesson Planning</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Time Table</a>
                                            <ul>
                                                <!--<li><a href="/index.php/core/room/create"></a></li>-->
                                                <li><a href="/index.php/core/timetable/create"> Set Time Table</a></li>
                                                <li><a href="/index.php/core/timetable/active">Active Timetable</a></li>
                                                <li><a href="/index.php/core/timetable/viewtimetable">View Batch Timetable</a></li>
                                                <li><a href="/index.php/core/timetable/viewteachertt">View Teacher Timetable</a></li>
                                                <li><a href="/index.php/core/timetable/proxy">Search Proxy</a></li>
                                                <li><a href="/index.php/core/timetable/workinghours">Teacher Working Hours</a></li>
                                                <li><a href="/index.php/core/timetable/timetableexport"> Time Table Export</a></li>
                                                <li><a href="/index.php/site/timetableimport">Time Table Import</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Exams</a>
                                            <ul>
                                                <li><a href="#">GPA</a>
                                                    <ul>
                                                        <li><a href="/index.php/core/term/create">Set Term</a></li>
                                                        <li><a href="/index.php/core/exam/create">Create Exam</a></li>
                                                        <li><a href="/index.php/core/gpaskills/create">GPA Skill</a></li>
                                                        <li><a href="/index.php/core/gpaskillsmark/create">GPA Skill Mark </a></li>
                                                        <li>
                                                        <a href="#">GPA Grade System</a>
                                                        <ul>
                                                            <li><a href="/index.php/core/gpagradeset/create">GPA Gradeset</a></li>
                                                            <li><a href="/index.php/core/gradescale/create">Set Grade Scale</a></li>
                                                            <li><a href="/index.php/core/gpagradesetmapping/create">Gradeset Mapping</a></li>
                                                        </ul>
                                                    </li>
                                                        <li><a href="/index.php/core/subjectcreditpoint/create">Subject Credit Point</a></li>
                                                        <li><a href="/index.php/core/totalmark/create">Total mark %</a></li>
                                                        <li><a href="/index.php/core/assessment/create">Set Assessment</a></li>
                                                        <li><a href="/index.php/core/setexam/create">Set Exam</a></li>
                                                        <li><a href="/index.php/core/setmarklist/create">Set Mark List</a></li>
                                                        <li><a href="/index.php/core/setmarklist/teachermarklist">Teacher Score Card</a></li>
                                                        <li><a href="/index.php/core/setmarklist/boardsheet">Broad Sheet</a></li>
                                                    <li><a href="/index.php/core/gpareportcardsettings/create">Report Card Settings</a></li>
                                                        <li><a href="/index.php/core/setmarklist/reportcard">Generate Report Card</a></li>
                                                     <li><a href="/index.php/core/assessment/assessmentimport">Assessment Mark Import</a></li>
                                                        <li><a href="/index.php/site/gpamarkimport">GPA Mark Import</a></li>
                                                        <li><a href="/index.php/site/gparemarks">Remarks Import</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">CCE</a>
                                                    <ul>
                                                        <li><a href="#">Initial Settings</a>
                                                            <ul>
                                                                <li><a href="/index.php/cce/ccecategory/create">CCE Category</a></li>
                                                                <li><a href="/index.php/cce/cceterm/create">CCE Assessment Terms</a></li>
                                                                <li><a href="/index.php/cce/cceassessment/create">CCE Assessment</a></li>
                                                                <li><a href="/index.php/cce/ccesubjectsub/create">CCE Subject Sub</a></li>
                                                                <li><a href="/index.php/cce/cceskills/create">CCE Skills</a></li>
                                                               <!-- <li><a href="/index.php/cce/cceindicators/create"></a></li>-->
                                                                <li><a href="/index.php/cce/ccegradeset/create">CCE Grade Set</a></li>
                                                                <li><a href="/index.php/cce/ccegrades/create">CCE Grades</a></li>
                                                                <li><a href="/index.php/cce/ccegradeskillmap/create">CCE Grade Skill Mapping</a></li>
                                                                <!--<li><a href="/index.php/cce/cceindicators/courseindicator">CCE  </a></li>-->
                                                                <li><a href="/index.php/cce/ccereportcardsettings/create">CCE Report Card Settings</a></li>
                                                                <li><a href="/index.php/cce/cceassigngrade/create">CCE Grade Description Class 1-5</a></li>
                                                            </ul>
                                                        </li>
                                                        <li><a href="#">CCE Exam</a>
                                                            <ul>
                                                                <li><a href="/index.php/cce/cceexamscheme/create">CCE Exam Scheme </a></li>
                                                                <li><a href="/index.php/cce/ccesetexam/create"> CCE Set Exam</a></li>
                                                                <li><a href="/index.php/cce/ccemarklist/create">CCE Scholastic Mark List</a></li>
                                                                <li><a href="/index.php/cce/ccecoscholasticmark/create">CCE Co-Scholastic Mark List</a></li>
                                                                <li><a href="/index.php/cce/ccemarklist/boardsheet">Broad Sheet</a></li>
                                                                <li><a href="/index.php/cce/ccemarklist/reportcard">Generate Report Card</a></li>
                                                                <li><a href="/index.php/site/ccemarkimport">Cce Mark Import</a></li>
                                                                <li><a href="/index.php/site/cceremarks">Remarks Import</a></li>

                                                            </ul>
                                                        </li> 
                                                    </ul>
                                                </li>
                                                <li><a href="#">Exam Hall</a>
                                                    <ul>
                                                        <li><a href="/index.php/core/examhall/create"> Exam Hall</a></li>
                                                        <li><a href="/index.php/core/seatarrangement/create">  Hall Arrangement</a></li>
                                                        <li><a href="/index.php/core/invigilationduties/create">Invigilation Duties</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Online Exam</a>
                                                    <ul>
                                                        <li><a href="/index.php/core/onlineexam/create"> New Online Exam</a></li>
                                                        <li><a href="/index.php/core/onlineexam/view_exam"> View Exam Details</a></li>
                                                        <li><a href="/index.php/core/onlineexamassign/evaluateexam"> Evaluate Exam</a></li>
                                                        <li><a href="/index.php/core/onlineexamassign/viewresult1">View Exam Results</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="/index.php/core/unittest/create">Unit Test</a></li>
                                                <li><a href="/index.php/core/setmarklist/publishresult"> Settings</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Assignments & Notes</a>
                                            <ul>
                                                <li><a href="/index.php/core/assignment/create">Add Assignment</a></li>
                                                <li><a href="/index.php/core/note/create">Add Notes</a></li>
                                                <li><a href="/index.php/site/assignmentimport">Assignments Import</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Certifications</a>
                                            <ul>
                                                <li><a href="/index.php/certifications/certificatetype/create">Certificate Type</a></li>
                                                <li><a href="/index.php/certifications/customcertificate/create">Custom Certificate</a></li>
                                                <li><a href="/index.php/certifications/generatecertificate/create">Generate Certificate</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Placements</a>
                                            <ul>
                                                <li><a href="/index.php/placements/placementcellmembers/create">Placement Cell Members</a></li>
                                                <li><a href="/index.php/placements/placementvendors/create">Placement Vendors</a></li>
                                                <li><a href="/index.php/placements/placementattendees/create">Attendees</a></li>
                                                <li><a href="/index.php/placements/placeddetails/create">Placed Details</a></li>
                                            </ul>
                                        </li>
                                        
                                        <li>
                                            <a href="#">Occurrence</a>
                                            <ul>
                                                <li><a href="/index.php/core/occurance/create">Occurrence Register </a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">Circular</a>
                                            <ul>
                                                <li><a href="/index.php/circular/circular/create">Circular</a></li>
                                            </ul>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-gift"></i><span>HR/Payroll</span></a>
                                    <ul>
                                        <!--<li><a href="/index.php/core/employeemaster/adminusers">Admin Users</a></li>-->
                                        <li><a href="#">Employee Management</a>
                                            <ul>
                                                <li><a href="/index.php/core/usertype/create">Add User Type</a></li>
                                                <li><a href="/index.php/core/department/create">Add Department</a></li>
                                                <li><a href="/index.php/core/designation/create">Add Designation</a></li>
                                                <li><a href="/index.php/core/employeedetails/create">Add Employee</a></li>
                                                <li><a href="/index.php/core/employeedetails/admin">Employee List</a></li>
                                                <li><a href="/index.php/bank/bankdetails/create">Add Bank Details</a></li>
                                                <li><a href="/index.php/core/employeedetails/reports">Print List</a> </li>
                                            <li><a href="/index.php/site/employeeattendanceimport">Employee Attendance Import</a></li>
                                           </ul>
                                        </li>
                                        <li><a href="#">Payroll</a>
                                            <ul>
                                                <li><a href="/index.php/payroll/payheadmaster/create">Pay Head</a></li>
                                                <li><a href="/index.php/payroll/payabletype/create">Payment  Types</a></li>
                                                <!--<li><a href="/index.php/payroll/leaveallowed/create">Allowed Leaves</a></li>-->
                                                <li><a href="/index.php/payroll/salarydetails/create">Salary Settings</a></li>
                                                <li><a href="/index.php/payroll/employeesalary/create">Employee Salary</a></li>
                                                <li><a href="/index.php/payroll/employeesalary/generatepayslip">Generate Pay Slip</a></li>
                                                <li><a href="/index.php/payroll/employeesalary/salaryreport">Salary Statement</a></li>
                                            </ul>
                                        </li>

                                        <!--<li><a href="#">Working Days</a></li>-->
                                        <li><a href="#">Leave Management</a>
                                            <ul>
                                                <li><a href="/index.php/leave/leavecategory/create">Leave Category</a></li>
                                                <li><a href="/index.php/leave/leavedetails/create">Leave Details</a></li>
                                                <li><a href="/index.php/leave/leaveapplication/create">Leave Application</a></li>
                                                <li><a href="/index.php/leave/leaveapplication/approve">Leave Approvals</a></li>
                                                <li><a href="/index.php/leave/leaveapplication/ondutylist">OD Approvals</a></li>
                                            </ul>
                                        </li>
                                        <!--                            <li><a href="#">Attendance</a>
                                                                        <ul>-->
                                        <li><a href="/index.php/core/employeeattendance/create">Attendance</a></li>
                                        <!--                                    <li><a href="#">Attendance Report</a></li>
                                                                        </ul>
                                                                    </li>-->
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-user"></i></i><span>Student</span></a>
                                    <ul>
                                        <li><a href="/st">Student List</a></li>
                                        <li><a href="/at">Attendance</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-hashtag"></i><span>Finance</span></a>
                                    <ul>
                                        <li>
                                            <a href="#">Fees</a>
                                            <ul>
                                                <li><a href="/index.php/core/feescategory/create">Fee Category</a></li>
                                                <li><a href="/index.php/core/feessubcategory/create">Fee Sub Category</a></li>
                                                <li><a href="/index.php/core/feessubcategoryfine/create">Fee Sub Category Fine</a></li>
                                                <li><a href="/index.php/core/feewaiver/create">Fee Waiver</a></li>
                                                <li><a href="/index.php/core/feetemplate/create">Fee Template</a></li>
                                                <li><a href="/index.php/core/feesallocation/create">Fee Allocation</a></li>
                                                <li><a href="/index.php/core/feesallocation/collection">Fee Collection</a></li>
                                                <li><a href="/index.php/core/feesallocation/quickpayment">Quick Payment</a></li>
                                                <li><a href="/index.php/core/feesallocation/reports">Reports</a></li>
                                                <li><a href="/index.php/site/feeallocationimport">Fees Allocation Import</a></li>
                                                <li><a href="/index.php/core/feescollection/feescollectionimport">Fees Collection Import</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Accounting</a>
                                            <ul>
                                                <li><a href="/index.php/accounting/accountgroup/create">Account Group</a></li>
                                                <li><a href="/index.php/accounting/vouchermaster/create">Voucher Master</a></li>
                                                <li><a href="/index.php/accounting/voucherhead/create">Voucher Head</a></li>
                                                <li><a href="/index.php/accounting/voucher/create">Create Voucher</a></li>
                                                <li><a href="/index.php/accounting/voucher/daybook">Day Book</a></li>
                                                <li><a href="/index.php/accounting/voucher/cashaccount">Cash Book</a></li>
                                                <li><a href="/index.php/accounting/voucher/bankaccount">Bank Book</a></li>
                                                <li>
                                                <a href="#">Report</a>
                                                <ul>
                                                    <li><a href="/index.php/accounting/voucher/report">Ledger Account </a></li>
                                                    <li><a href="/index.php/accounting/voucher/trialbalance">Trial Balance </a></li>
                                                </ul>
                                            </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-book"></i><span>Library</span></a>
                                    <ul>
                                        <li><a href="/index.php/library/bookcategory/create">Add Category</a></li>
                                        <li><a href="/index.php/library/librarybooks/create">Add Books</a></li>
                                        <li><a href="/index.php/library/bookissue/create">Issue Book</a></li>
                                        <li><a href="/index.php/library/bookissue/requestdetails">Request Details</a></li>
                                        <li><a href="/index.php/library/bookreturn/create">Book Return</a></li>
                                        <li><a href="/index.php/library/librarybooks/reports">Reports</a></li>
                                        <li><a href="/index.php/site/libraryimport">Import</a></li>
                                     <li><a href="/index.php/library/librarybooks/libraryexport">Export</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-bus"></i><span>Transport</span></a>
                                    <ul>
                                        <li><a href="/index.php/transport/transportvehicle/create">Add Vehicle</a></li>
                                        <li><a href="/index.php/transport/transportdriver/create">Add Driver</a></li>
                                        <li><a href="/index.php/transport/routemaster/create">Add Route</a></li>
                                        <li><a href="/index.php/transport/routedetails/create">Add Destination</a></li>
                                        <li><a href="/index.php/transport/transportallocation/create">Transport Allocation </a></li>
                                        <li><a href="/index.php/transport/transportfeecollection/create">Fee Collection</a></li>
                                        <li><a href="/index.php/site/transportallocationimport">Import</a></li>
                                        <li><a href="/index.php/transport/transportfeecollection/smsalert">SMS Alert</a></li>
                                    <li><a href="/index.php/transport/routemaster/reports">Report</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-hotel"></i></i><span>Hostel</span></a>
                                    <ul>
                                        <li><a href="/index.php/hostel/hosteltype/create">Hostel Details</a></li>
                                        <li><a href="/index.php/hostel/hostelroom/create">Hostel Room</a></li>
                                        <li><a href="/index.php/hostel/hostelregistration/create">Hostel Allocation</a></li>
                                        <li><a href="/index.php/hostel/hostelregistration/requestdetails">Request Details</a></li>
                                        <li><a href="/index.php/hostel/hosteltransfer/create">Hostel Transfer/Vacate</a></li>
                                        <li><a href="/index.php/hostel/hostelregister/create">Hostel Register</a></li>
                                        <li><a href="/index.php/hostel/hostelvisitors/create">Hostel Visitors</a></li>
                                        <li><a href="/index.php/hostel/hostelfeecollection/create">Hostel Fee Collection</a></li>
                                        <li>
                                            <a href="#">Reports</a>
                                            <ul>
                                                <li><a href="/index.php/hostel/hostelroom/hosteldetailsreport">Hostel Details Report </a></li>
                                                <li><a href="/index.php/hostel/hostelroom/availableroomreport">Room Availability Report</a></li>
                                                <li><a href="/index.php/hostel/hostelroom/requestreport">Room Request Report</a></li>
                                                <li><a href="/index.php/hostel/hostelroom/occupiedreport">Room Occupancy Report</a></li>
                                                <li><a href="/index.php/hostel/hostelfeecollection/feereport">Fee Reports</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-envelope"></i><span>Messages/SMS</span></a>
                                    <ul>
                                        <li><a href="/index.php/core/email/email">Mailbox</a></li>
                                        <li><a href="/index.php/sms/smssettings/create">SMS Settings</a></li>
                                        <li><a href="/index.php/sms/visitorsmssettings/create">Visitor SMS Settings</a></li>
                                        <li><a href="/m">Bulk SMS</a></li>
                                        <li>
                                            <a href="#">Email</a>
                                            <ul>
                                                <li><a href="/index.php/sms/emailsettings/create">Email Settings</a></li>
                                                <li><a href="/index.php/sms/emailtemplate/create">Create Template</a></li>
                                                <li><a href="/index.php/sms/sendmail/mail">Send email</a></li>

                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-folder"></i><span>Store Management</span></a>
                                    <ul>
                                        <li><a href="/index.php/inventory/vendors/create">Vendors</a></li>
                                        <li><a href="/index.php/inventory/inventorycategory/create">Inventory Category</a></li>
                                        <li><a href="/index.php/inventory/inventoryitem/create">Inventory Item</a></li>
                                        <li><a href="/index.php/inventory/purchasereceipts/create">Purchase Receipts</a></li>
                                    
                                        <li><a href="/index.php/inventory/inventoryissue/create">Inventory Issue</a></li>
                                        <li><a href="/index.php/inventory/inventoryitem/stockregister">Stock Register</a></li>
                                        <li>
                                    <a href="#">Reports</a>
                                    <ul>
                                    <li><a href="/index.php/inventory/inventoryissue/issuedreport">Issued Report</a></li>
                                    <li><a href="/index.php/inventory/inventoryissue/inventoryreports">Inventory Report</a></li>
                                    </ul>
                                    </li>
                                   </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-database"></i><span>Performance</span></a>
                                    <ul>
                                        <!--<li><a href="/index.php/core/employeemaster/adminusers">Admin Users</a></li>-->
                                        <li><a href="#">GPA</a>
                                            <ul>
                                                <li><a href="/index.php/core/setmarklist/studentperformance">Student Performance</a></li>
                                                <li><a href="/index.php/core/setmarklist/courseperformance">Course Performance</a></li>
                                                <li><a href="/index.php/core/setmarklist/subjectperformance">Subject Performance</a></li>
                                            <li><a href="/index.php/core/setmarklist/teacherperformance">Teacher Performance</a></li>
                                           </ul>
                                        </li>
                                        <li><a href="#">CCE</a>
                                            <ul>
                                                <li><a href="/index.php/cce/ccemarklist/studentperformance">Student Performance</a></li>
                                                <li><a href="/index.php/cce/ccemarklist/courseperformance">Course Performance</a></li>
                                                <li><a href="/index.php/cce/ccemarklist/subjectperformance"> Subject Performance</a></li>
                                             <li><a href="/index.php/cce/ccemarklist/teacherperformance">Teacher Performance</a></li>
                                            </ul>
                                        </li>
                                         <li><a href="/index.php/core/teachercomments/create">Teacher Comments</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="fa fa-calendar"></i><span>Events</span></a>
                                    <ul>
                                        <li><a href="/index.php/events/eventtype/create"> Event Types</a></li>
                                        <li><a href="/index.php/events/event/create"> Add Events</a></li>
                                        <li><a href="eventreportlist"> Event Reports</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class=" icon-link2"></i><span>Integration</span></a>
                                    <ul>
                                        <li><a href="/integration/vehicletracking">Vehicle Tracking</a> </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#"><i class="icon-file-text"></i><span>Task Manager</span></a>
                                    <ul>
                                        <li><a href="/index.php/core/taskmanager/create">Assign Task</a></li>
                                        <li><a href="/index.php/core/taskmanager/admin">Task Details</a></li>
                                    </ul>
                                </li>
                                          <li>
                                    <a href="#"><i class="icon-copy3"></i><span>Reports</span></a>
                                    <ul>
                                        <li><a href="/index.php/core/student/studentreport">Student Reports</a> </li>
                                        <li><a href="/index.php/core/student/studentdetailsreport">Student Details</a> </li>
                                        <li><a href="/index.php/core/subject/electivereport">Elective Reports</a> </li>
                                        <li><a href="/index.php/core/feesallocation/duereport">Fee Due Reports</a> </li>
                                        <li><a href="/index.php/core/feesallocation/paidreport">Fee Paid Reports</a> </li>
                                        <li><a href="/index.php/core/studentabsent/attendencereport"> Absentees Reports</a> </li>
                                        <li><a href="student/classsummary">Class Summary Reports</a> </li>
                                        
                                        <li><a href="/index.php/core/student/admissionreport">Admission Report</a></li>
                                        <li><a href="/index.php/core/leavereport/leavesreport">Leave Report</a></li>
                                        <li><a href="/index.php/core/visitors/visitorslistreport">Visitors List</a></li>
                                        <li><a href="/index.php/core/application/enquireylist">Follow up Reports</a></li>
                                     </ul>
                                </li>
                                  <li>
                                    <a href="#"><i class="glyphicon glyphicon-cloud-download"></i><span>Data Export</span></a>
                                    <ul>
                                        <li><a href="/index.php/site/dataexport">Export</a> </li>
                                    </ul>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

@yield('content')


<style>
    #loader {
        position: absolute;
        left: 50%;
        top: 50%;
        z-index: 1;
        width: 25px;
        height: 25px;
        margin: 20px 0 0 20px;
        border: 5px solid #fff;
        border-radius: 50%;
        border-top: 5px solid #2196F3;
        border-bottom: 5px solid #2196F3;
        width: 30px;
        height: 30px;
        -webkit-animation: spin 2s linear infinite;
        animation: spin 2s linear infinite;
    }
    @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    span.one {
        background-color:rgb(199,209,214)
    }
    span.two{
        background-color:rgb(105,203,248)
    }
    span.fone {
        background-color:rgb(170,175,205)
    }
    span.ftwo{
        background-color:rgb(175,199,171)
    }
    span.fthree {
        background-color:rgb(192,168,198)
    }
    body {
        /*margin: 40px 10px;*/
        /*        padding: 0;
                font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
                font-size: 14px;*/
    }
    #calendar {
        max-width: 900px;
        margin: 0 auto;
    }
</style>




<script>
    $(document).ready(function () {
        // $('#feescollecteddaily').empty();
        $.ajax({
            type: "POST",
            url: "/index.php/core/feesallocation/paidreportdaily",
            data: {},
            dataType: "html",
            success: function (data) {
                $('#feescollecteddaily').append(data);
            }
        });
    });

    var day = ["06/8","06/9","06/10","06/11","06/12","Today","06/14"];
    var emp = ["0","0","0","0","0","0","0"];
    var stud = ["0","0","0","0","0","0","0"];

    if (typeof atten === 'undefined') {

        var randomScalingFactor = function () {
            return Math.round(Math.random() * 100)
        };
        var randomColorFactor = function () {
            return Math.round(Math.random() * 255)
        };

        var attenData = {
            labels: day,
            datasets: [
                {
                    fillColor: "rgba(199,209,214,0.2)",
                    strokeColor: "rgba(199,209,214,1)",
                    pointColor: "rgba(199,209,214,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(199,209,214,1)",
                    label: "Employee",
                    data: emp
                },
                {
                    fillColor: "rgba(105,203,248,0.2)",
                    strokeColor: "rgba(105,203,248,1)",
                    pointColor: "rgba(105,203,248,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(105,203,248,1)",
                    label: "Student",
                    data: stud
                },
            ]
        }
        var atten = document.getElementById('atten').getContext('2d');
        // atten.canvas.width = 100;
        atten.canvas.height = 150;
        new Chart(atten).Bar(attenData, {
            responsive: true, maintainAspectRatio: true

        });

    }
    else {

        atten.destroy();
        var attenData = {
            labels: day,
            datasets: [
                {
                    fillColor: "rgba(220,220,220,0.9)",
                    strokeColor: "rgba(220,220,220,0.8)",
                    pointColor: "rgba(220,220,220,0.7)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1.1)",
                    label: "Employee",
                    data: emp
                },
                {
                    fillColor: "rgba(105,203,248,0.9)",
                    strokeColor: "rgba(105,203,248,0.8)",
                    pointColor: "rgba(105,203,248,0.7)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(105,203,248,1.1)",
                    label: "Student",
                    data: stud
                },
            ]

        }

        var atten = document.getElementById('atten').getContext('2d');
        atten.canvas.height = 80;

        new Chart(atten).Bar(attenData, {
            responsive: true, maintainAspectRatio: true

        });


    }
    ;
    $(function () {
        $('#todo_content').keydown(function (e) {
            if (e.shiftKey || e.ctrlKey || e.altKey) {
                e.preventDefault();
            } else {
                var key = e.keyCode;
                if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105) || (key == 46) || (key = 45) || (key = 190))) {
                    e.preventDefault();
                }
            }
        });
    });
    $(function () {
        $('#todo_subject').keydown(function (e) {
            if (e.shiftKey || e.ctrlKey || e.altKey) {
                e.preventDefault();
            } else {
                var key = e.keyCode;
                if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105) || (key == 46) || (key = 45) || (key = 190))) {
                    e.preventDefault();
                }
            }
        });
    });
    $(function () {
        $('#todo_contentedit').keydown(function (e) {
            if (e.shiftKey || e.ctrlKey || e.altKey) {
                e.preventDefault();
            } else {
                var key = e.keyCode;
                if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105) || (key == 46) || (key = 45) || (key = 190))) {
                    e.preventDefault();
                }
            }
        });
    });
    $(function () {
        $('#todo_subjectedit').keydown(function (e) {
            if (e.shiftKey || e.ctrlKey || e.altKey) {
                e.preventDefault();
            } else {
                var key = e.keyCode;
                if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105) || (key == 46) || (key = 45) || (key = 190))) {
                    e.preventDefault();
                }
            }
        });
    });
    $('#todobutton').click(function () {
        var todo = $("#todo_subject").val();
        var date = $("#todo_date").val();
        var content = $("#todo_content").val();
        if (todo == "" || date == "" || content == "") {
            alert("Please enter all fields");
            return;
        } 
        else if (!(/^[a-zA-Z0-9\-\s\,\.]+$/.test(content)) || !(/^[a-zA-Z0-9\-\s\,\.]+$/.test(todo))) {
            alert("Avoid special characters");
            return;
        }
        else {
            $.ajax({
                url: '/index.php/site/savetodo',
                type: 'POST',
                data: {todocontent: $('#todo_content').val(), todo_date: $('#todo_date').val(), todo_subject: $('#todo_subject').val()},
                success: function (data) {
                    location.reload();
                }

            });
        }

    });

// Date picker
    $('.pickadate').pickadate({
        labelMonthNext: 'Go to the next month',
        labelMonthPrev: 'Go to the previous month',
        labelMonthSelect: 'Pick a month from the dropdown',
        labelYearSelect: 'Pick a year from the dropdown',
        selectMonths: true,
        selectYears: true
    });

// Time picker
    $('.pickatime').pickatime({
        // options
    });


</script>

<script>
    function feegraph() {
        $('#loader').show("slow");
        $.ajax({
            type: "POST",
            url: "/index.php/site/drawfeegraph",
            success: function (response) {
                $('#loader').hide("slow");
                $('#feereport_graph').html(response);
            }

        });
    }

</script>  




<!-- Load jQuery -->
<script type="text/javascript" src="{{ asset('js/jquery.min.js') }}"></script>

<!-- Load Moment extension -->
<script type="text/javascript" src="{{ asset('js/plugins/moment.min.js') }}"></script>

<!-- Load plugin -->
<script type="text/javascript" src="{{ asset('js/plugins/datepaginator.min.js') }}"></script>
<!-- Load base -->
<script type="text/javascript" src="{{ asset('js/plugins/picker.js') }}"></script>

<!-- Load date picker -->
<script type="text/javascript" src="{{ asset('js/plugins/picker.date.js') }}"></script>
<!-- Load time picker -->

<!-- <script type="text/javascript" src="{{ asset('js/plugins/picker.time.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/bootstrap-timepicker.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/pnotify.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/country.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/spectrum.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/picker_color.js') }}"></script> -->

<!-- 
<script type="text/javascript" src="{{ asset('js/custom.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/components_notifications_pnotify.js') }}"></script>
 -->

<!-- <script type="text/javascript" src="{{ asset('js/yiigridview.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery-ui.min.js') }}"></script> -->
<script type="text/javascript">
/*<![CDATA[*/
jQuery(function($) {
jQuery('#user').autocomplete({'minLength':'1','select':function( event, ui ) {
    $("#hidden-field").val(ui.item.value);                
    return true;  
    },'source':'/index.php/core/institution/autocompleteUsers'});
});
/*]]>*/
</script>

<!-- Core JS files -->
<!-- <script type="text/javascript" src="{{ asset('js/plugins/pace.min.js') }}"></script> -->
<script type="text/javascript" src="{{ asset('js/plugins/bootstrap.min.js') }}"></script>
<!-- <script type="text/javascript" src="{{ asset('js/plugins/blockui.min.js') }}"></script> -->
<!-- /core JS files -->
<!-- <script type="text/javascript" src="{{ asset('js/plugins/jquery.yiiactiveform.js') }}"></script>
<script src="{{ asset('js/Chart.js') }}"></script>
<script src="{{ asset('js/Chart.StackedBar.js') }}"></script> -->
<!-- Theme JS files -->
<!-- 
<script type="text/javascript" src="{{ asset('js/plugins/d3.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/d3_tooltip.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/switchery.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/uniform.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/bootstrap_multiselect.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/daterangepicker.js') }}"></script>
 -->
<!-- 
<script type="text/javascript" src="{{ asset('js/plugins/fullcalendar.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/select2.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/echarts.js') }}"></script>
 -->

<!-- <script type="text/javascript" src="{{ asset('js/user_pages_profile.js') }}"></script> -->

<!-- 
<script type="text/javascript" src="{{ asset('js/plugins/legacy.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/picker_date.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/datepicker.min.js') }}"></script>
 -->

<!-- <script type="text/javascript" src="{{ asset('js/effects.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/jgrowl.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/anytime.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/limitless.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/bar.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/line.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/plugins/jquery.ba-bbq.js') }}"></script> -->

<!-- <script src="https://apis.google.com/js/platform.js" async defer></script>
<script src="https://apis.google.com/js/client.js" async defer></script>
<script src="https://apis.google.com/js/platform.js?onload=onLoad" async defer></script> -->
<script>
                                                   
    window.addEventListener('keydown',function(e){
            if(e.keyIdentifier=='U+000A'||e.keyIdentifier=='Enter'||e.keyCode==13){
                if(e.target.nodeName=='INPUT'&&e.target.type=='text'){
                e.preventDefault();return false;
                }
            }
        },true);   
       $(function () {
            ebro_datepicker.init();

        });

        ebro_datepicker = {
            init: function () {
                if ($('.ebro_datepicker').length) {
                    $('.ebro_datepicker').datepicker()
                }
                if (($('#dpStart').length) && ($('#dpEnd').length)) {
                    $('#dpStart').datepicker().on('changeDate', function (e) {
                        $('#dpEnd').datepicker('setStartDate', e.date);
                    });
                    $('#dpEnd').datepicker().on('changeDate', function (e) {
                        $('#dpStart').datepicker('setEndDate', e.date)
                    });
                }
            }
        };
//   $('#createEventModal').modal('show');
        


// Date picker
        $('.pickadate').pickadate({
            labelMonthNext: 'Go to the next month',
            labelMonthPrev: 'Go to the previous month',
            labelMonthSelect: 'Pick a month from the dropdown',
            labelYearSelect: 'Pick a year from the dropdown',
            selectMonths: true,
            selectYears: true
        });
        function getsearchdetails() {
            $('#searchautocomplete').show("slow");
            var searchvalue = document.getElementById('hidden-field').value;
            if (searchvalue === "") {
//  alert("arya");
            } else {
                alert("success");
            }
        }
        function signOut() {
            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function () {
                console.log('User signed out.');
            });
        }

        function onLoad() {
            gapi.load('auth2', function () {
                gapi.auth2.init();
            });
        }
        function autocompletesearch() {
            var studentemail = $('#user').val();
            if (studentemail === "") {
                alert('Please select a user');
                return false;
            }
        }
        $(document).ready(function () {
            $('#moodlemodal').hide();
        });
        function showmodal() {
            $('#moodlemodal').show();
        }
        function saveitem() {
            var link = $('#link').val();
            var username = $('#username').val();
            var password = $('#password').val();
            if (link === "" || username === "" || password === "") {
                alert("All fields are mandatory.")
                return false;
            }
        }
</script>


</body>
</html>
