<div class="modal-content login-form col-lg-6" id="moodlemodal">
                <div id="modal-unlock" class="modal fade col-md-12">
                    <div class="modal-dialog">
                        <div class="modal-content login-form">

                            <!-- Form -->
                            <form class="modal-body" id="loginForm" action="/index.php/site/moodle" method="post">
                                <!--                                <div class="thumbnail"><div class="thumb thumb-slide" >-->
                                <img src="/images/index.jpg" alt="" class="img-responsive center-block" style="width:100px; height:100px;"/>
                                <!--                                                                    </div></div>-->

                                <h6 class="content-group text-center text-semibold no-margin-top">Moodle credentials <small class="display-block">Unlock your account</small></h6>
                                <div class="form-group has-feedback">
                                    <input type="text" class="form-control" name="username" placeholder="Your Username" id="username">
                                    <div class="form-control-feedback">
                                        <i class="icon-user-lock text-muted"></i>
                                    </div>
                                </div>
                                <div class="form-group has-feedback">
                                    <input type="text" class="form-control" name="password" placeholder="Your Password" id="password">
                                    <div class="form-control-feedback">
                                        <i class="icon-user-lock text-muted"></i>
                                    </div>
                                </div>


                                <button type="submit" class="btn bg-slate btn-block" onclick=" return  saveitem()">Save <i class="icon-circle-right2 position-right"></i></button>
                                <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Cancel</button>
                            </form>
                            <!-- /form -->

                        </div>
                    </div>
                </div>
                <!-- /form -->

            </div>

            <div class="navbar navbar-default navbar-sm navbar-fixed-bottom">
                <ul class="nav navbar-nav no-border visible-xs-block">
                    <li>
                        <a data-target="#navbar-second" data-toggle="collapse" class="text-center collapsed">
                            <i class="icon-circle-up2"></i>
                        </a>
                    </li>
                </ul>
                <div id="navbar-second" class="navbar-collapse collapse">
                    <div class="navbar-text">
                        &copy; 2018. 
                    </div>
                </div>
            </div> 