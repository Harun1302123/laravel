<?php
	class EMDAD_infoSMS 
		{ 
			function __construct($senderid,$to,$message) 
			{
				
				$to=str_replace('+88','',$to);
				$senderid=urlencode("$senderid");
				$message=urlencode("$message");
				$api_key='C20029585c447bafaba5c4.02415382';
				$sms_user=urlencode("$api_key");
				$sendsms = "http://esms.dianahost.com/smsapi?"
				. "api_key=$api_key"
				. "&type=text"
				. "&contacts=$to"
				. "&senderid=$senderid"
				. "&msg=$message";
				$getsmsstatus=file_get_contents($sendsms);
			}
		}
	$phone= "";
	$message="Hi.. Mr. Harun....";
	$sendsms = new EMDAD_infoSMS("8801847169884", $phone, $message);
	echo "<script>window.location.href = 'st'</script>";
?>

<!-- https://medium.com/techtrument/send-sms-from-laravel-application-d3ac9d1a4fac -->
<!-- https://stackoverflow.com/questions/45959823/i-want-to-integrate-a-sms-api-on-my-laravel-application -->
