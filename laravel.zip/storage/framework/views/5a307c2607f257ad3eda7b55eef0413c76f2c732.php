<?php $__env->startSection('content'); ?>

			<div class="content-wrapper">
                <div class="content"> <!-- content start -->
                	
                	<form id="studentabsent-form" action="" method="post">
                		<div class="col-sm-12">
					        <ul class="nav nav-tabs nav-tabs-highlight">
					            <li class="active"><a href="#tbb_a" data-toggle="tab">Attendance (Daily &amp; Subject Wise)</a></li>
					            <li class=""><a href="#tbb_b" data-toggle="tab">View Attendance</a></li>
					        </ul><br>
					        <div class="tab-content">
					            <div class="tab-pane active" id="tbb_a">
					                <div class="row">
					                    <div class="col-sm-12">
					                        <div class="panel panel-default">
					                            <div class="panel-heading">
					                                <h4 class="panel-title">Attendance </h4>
					                            </div>
					                            <div class="panel-body">
					                                <div class="form-group col-sm-3 validating" id="course">
					                                    <label for="reg_input" class="req">Course</label>
					                                    <select class="form-control" name="Studentabsent[courseid]" id="Studentabsent_courseid">
															<option value="">SelectCourse</option>
														</select>
														<div class="school_val_error" id="Studentabsent_courseid_em_" style="display:none"></div>
													</div>  
					                                <div class="form-group col-sm-3 validating" id="Batch_subject" style="">
					                                    <label for="reg_input" class="req">Batch</label>
					                                    <select class="form-control" name="Studentabsent[batchid]" id="Studentabsent_batchid">
					                                    	<option value="">Select</option>
					                                    </select>
					                                    <div class="school_val_error" id="Studentabsent_batchid_em_" style="display:none"></div>
					                                </div> 

					                                <div class="form-group col-sm-3 validating" id="subject" style="">
					                                    <label for="reg_input" class="req">Subject</label>
					                                    <select class="form-control" name="Studentabsent[subjectid]" id="Studentabsent_subjectid">
					                                    	<option value="">Select</option>
					                                    </select><div class="school_val_error" id="Studentabsent_subjectid_em_" style="display:none"></div>
					                                </div> 

					                                <div class="form-group col-sm-3" id="date" style="">
					                                    <label for="reg_input_name" class="req">Date </label>
					                                    <div data-date-format="dd-mm-yyyy" class="input-group date">

					                                        <input placeholder="Date" class="form-control pickadate picker__input" value="2019-06-15" name="Studentabsent[date]" id="Studentabsent_date" type="text" maxlength="6" readonly="" aria-haspopup="true" aria-expanded="false" aria-readonly="false" aria-owns="Studentabsent_date_root"><div class="picker" id="Studentabsent_date_root" aria-hidden="true"><div class="picker__holder"><div class="picker__frame"><div class="picker__wrap"><div class="picker__box"><div class="picker__header"><select class="picker__select--year" disabled="" aria-controls="Studentabsent_date_table" title="Pick a year from the dropdown"><option value="1969">1969</option><option value="1970">1970</option><option value="1971">1971</option><option value="1972">1972</option><option value="1973">1973</option><option value="1974">1974</option><option value="1975">1975</option><option value="1976">1976</option><option value="1977">1977</option><option value="1978">1978</option><option value="1979">1979</option><option value="1980">1980</option><option value="1981">1981</option><option value="1982">1982</option><option value="1983">1983</option><option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option><option value="2019" selected="">2019</option><option value="2020">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option><option value="2032">2032</option><option value="2033">2033</option><option value="2034">2034</option><option value="2035">2035</option><option value="2036">2036</option><option value="2037">2037</option><option value="2038">2038</option><option value="2039">2039</option><option value="2040">2040</option><option value="2041">2041</option><option value="2042">2042</option><option value="2043">2043</option><option value="2044">2044</option><option value="2045">2045</option><option value="2046">2046</option><option value="2047">2047</option><option value="2048">2048</option><option value="2049">2049</option><option value="2050">2050</option><option value="2051">2051</option><option value="2052">2052</option><option value="2053">2053</option><option value="2054">2054</option><option value="2055">2055</option><option value="2056">2056</option><option value="2057">2057</option><option value="2058">2058</option><option value="2059">2059</option><option value="2060">2060</option><option value="2061">2061</option><option value="2062">2062</option><option value="2063">2063</option><option value="2064">2064</option><option value="2065">2065</option><option value="2066">2066</option><option value="2067">2067</option><option value="2068">2068</option><option value="2069">2069</option></select><select class="picker__select--month" disabled="" aria-controls="Studentabsent_date_table" title="Pick a month from the dropdown"><option value="0">January</option><option value="1">February</option><option value="2">March</option><option value="3">April</option><option value="4">May</option><option value="5" selected="">June</option><option value="6">July</option><option value="7">August</option><option value="8">September</option><option value="9">October</option><option value="10">November</option><option value="11">December</option></select><div class="picker__nav--prev" data-nav="-1" role="button" aria-controls="Studentabsent_date_table" title="Go to the previous month"> </div><div class="picker__nav--next" data-nav="1" role="button" aria-controls="Studentabsent_date_table" title="Go to the next month"> </div></div><table class="picker__table" id="Studentabsent_date_table" role="grid" aria-controls="Studentabsent_date" aria-readonly="true"><thead><tr><th class="picker__weekday" scope="col" title="Sunday">Sun</th><th class="picker__weekday" scope="col" title="Monday">Mon</th><th class="picker__weekday" scope="col" title="Tuesday">Tue</th><th class="picker__weekday" scope="col" title="Wednesday">Wed</th><th class="picker__weekday" scope="col" title="Thursday">Thu</th><th class="picker__weekday" scope="col" title="Friday">Fri</th><th class="picker__weekday" scope="col" title="Saturday">Sat</th></tr></thead><tbody><tr><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1558807200000" role="gridcell">26</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1558893600000" role="gridcell">27</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1558980000000" role="gridcell">28</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1559066400000" role="gridcell">29</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1559152800000" role="gridcell">30</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1559239200000" role="gridcell">31</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559325600000" role="gridcell">1</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559412000000" role="gridcell">2</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559498400000" role="gridcell">3</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559584800000" role="gridcell">4</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559671200000" role="gridcell">5</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559757600000" role="gridcell">6</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559844000000" role="gridcell">7</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1559930400000" role="gridcell">8</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560016800000" role="gridcell">9</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560103200000" role="gridcell">10</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560189600000" role="gridcell">11</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560276000000" role="gridcell">12</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560362400000" role="gridcell">13</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560448800000" role="gridcell">14</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--today picker__day--selected picker__day--highlighted" data-pick="1560535200000" role="gridcell" aria-activedescendant="true">15</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560621600000" role="gridcell">16</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560708000000" role="gridcell">17</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560794400000" role="gridcell">18</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560880800000" role="gridcell">19</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1560967200000" role="gridcell">20</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561053600000" role="gridcell">21</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561140000000" role="gridcell">22</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561226400000" role="gridcell">23</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561312800000" role="gridcell">24</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561399200000" role="gridcell">25</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561485600000" role="gridcell">26</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561572000000" role="gridcell">27</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561658400000" role="gridcell">28</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561744800000" role="gridcell">29</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1561831200000" role="gridcell">30</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1561917600000" role="gridcell">1</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1562004000000" role="gridcell">2</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1562090400000" role="gridcell">3</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1562176800000" role="gridcell">4</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1562263200000" role="gridcell">5</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1562349600000" role="gridcell">6</div></td></tr></tbody></table><div class="picker__footer"><button class="picker__button--today" type="button" data-pick="1560535200000" disabled="" aria-controls="Studentabsent_date">Today</button><button class="picker__button--clear" type="button" data-clear="1" disabled="" aria-controls="Studentabsent_date">Clear</button><button class="picker__button--close" type="button" data-close="true" disabled="" aria-controls="Studentabsent_date">Close</button></div></div></div></div></div></div><div class="school_val_error" id="Studentabsent_date_em_" style="display:none"></div>                                        <span class="input-group-addon"><i class="icon-calendar"></i></span>
					                                    </div>
					                                </div>
					                            </div>
					                        </div>
					                    </div>
					                </div>
					                <p>
					                </p>
					                <div class="alert alert-warning warning">
					                    <span class="icon-warning icon-2x" style="color:orange"></span>Put mark on students who were present. 
					                </div>
					                <p></p>
					                <div class="row">
					                    <div class="col-sm-12" id="gridview">
					                    	<form action="<?php echo e(action('StudentController@message')); ?>" method="POST">
					                    		<?php echo e(csrf_field()); ?>

						                        <div class="panel panel-default" id="attendancediv" style="">
						                            <div class="panel-heading">
						                                <h4 class="panel-title">Attendance </h4>
						                            </div>
						                            <div class="form-group">
						                            	<input type="text" name="massage" placeholder="Message" class="form-control">
						                            </div>
						                            <div class="table-responsive">
						                                <table class="table responsive table-bordered table-striped" id="studentattendence">
						                                    <thead>
						                                        <tr>
						                                            <th data-hide="phone" class="footable-last-column" width="15%"><input type="checkbox" id="checkall">&nbsp;&nbsp;&nbsp;Check all</th>
						                                            <th data-hide="phone,tablet" width="10%">Roll No.</th>
						                                            <th data-hide="phone,tablet" width="15%">ID</th>
						                                            <th data-hide="phone,tablet" width="30%">Student Name</th>
						                                            <th data-hide="phone,tablet" width="15%">Class</th>
																	<th data-hide="phone" class="footable-last-column" width="15%"><input type="checkbox" id="checkstatus" class="checkbox1">&nbsp;&nbsp;&nbsp;Check all</th>
						                                        </tr>
						                                    </thead>
						                                    <tbody>
						                                    	<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						                                    	<tr>
						                                    		<td data-id="220">
						                                    			<input type="checkbox" name="mobile" value="<?php echo e($student->mobile); ?>" class="checkbox">
						                                    		</td>
						                                    		<td>101</td>
						                                    		<td>1</td>
						                                    		<td><?php echo e($student->name); ?></td>
						                                    		<td>8</td>
						                                    		<td>
						                                    			<input type="checkbox" name="attendence1" class="checkbox1">
						                                    		</td>
						                                    	</tr>
						                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                                    </tbody>
						                                </table>
						                            </div>
						                        </div>
						                        <input type="submit" name="sms" value="Message" class="btn btn-info">
					                        </form>
					                    </div>
					                </div>
					                <div class="row">
					                    <div class="col-sm-5">
					                        <!-- <p>&nbsp;&nbsp; <a href="javascript:saveabsent();" class="btn btn-info" align="right">Save</a></p>  -->
					                    </div>
					                </div>
					                <div class="row">
					                    <div class="col-sm-5">
					                        <p>&nbsp;&nbsp; </p> 
					                    </div>
					                </div>
					            </div>
					            <div class="tab-pane" id="tbb_b">
					                <div class="row">
					                    <div class="col-sm-12">
					                        <div class="panel panel-default">
					                            <div class="panel-heading">
					                                <h4 class="panel-title">Attendance</h4>
					                            </div>
					                            <div class="panel-body">
					                                <div class="form-group col-sm-3" id="course">
					                                    <label for="reg_input" class="req">Course</label>
					                                    <select class="form-control" name="Studentabsent[courseid1]" id="Studentabsent_courseid1">
															<option value="">SelectCourse</option>
														</select>
														<div class="school_val_error" id="Studentabsent_courseid1_em_" style="display:none">
														</div>
													</div>

					                                <div class="form-group col-sm-3" id="Batch_subject1" style="display:none;">
					                                    <label for="reg_input" class="req">Batch</label>
					                                    <select class="form-control" name="Studentabsent[batchid1]" id="Studentabsent_batchid1">
															<option value="">SelectBatch</option>
														</select>
														<div class="school_val_error" id="Studentabsent_batchid1_em_" style="display:none">
														</div>
													</div> 

					                                <div class="form-group col-sm-3" id="subject1" style="display:none;">
					                                    <label for="reg_input" class="req">Subject</label>
					                                    <select class="form-control" name="Studentabsent[subjectid1]" id="Studentabsent_subjectid1">
															<option value="">Select Subject</option>
														</select>
														<div class="school_val_error" id="Studentabsent_subjectid1_em_" style="display:none"></div>
													</div> 
					                                <div class="form-group col-sm-3">
					                                    <label for="reg_input" class="req">Year</label>
					                                    <select class="form-control" name="Studentabsent[year]" id="Studentabsent_year">
															<option value="">Select Year</option>
														</select>
														<div class="school_val_error" id="Studentabsent_year_em_" style="display:none"></div>
													</div>
					                                <div class="form-group col-sm-3">
					                                    <label for="reg_input_name">Month</label>
					                                    <select maxlength="6" class="form-control" value="06" name="Studentabsent[date15]" id="Studentabsent_date15">
															<option value="0">Select</option>
															<option value="1">January</option>
															<option value="2">February</option>
															<option value="3">March</option>
															<option value="4">April</option>
															<option value="5">May</option>
															<option value="6">June</option>
															<option value="7">July</option>
															<option value="8">August</option>
															<option value="9">September</option>
															<option value="10">October</option>
															<option value="11">November</option>
															<option value="12">December</option>
														</select>
														<div class="school_val_error" id="Studentabsent_date15_em_" style="display:none"></div>
													</div>
					                                <div class="form-group col-sm-3"></div>
					                                <div class="form-group col-sm-3">
					                                    <input type="button" onclick="printDiv('print')" class="btn btn-danger" value="Print" report="">
					                                </div>
					                            </div>
					                        </div>
					                    </div>
					                </div>
					                <div class="row" id="print">
					                    <div class="col-sm-12" id="gridview">
					                        <div class="panel panel-default" id="attendance">
					                            <div class="panel-heading">
					                                <h4 class="panel-title" id="reporttitle">Attendance Report</h4>
					                            </div>
					                            <div class="table-responsive">
					                                <table class="table responsive table table-bordered table table-striped" id="employeeattendence1">
					                                   
					                                </table>
					                            </div>
					                        </div>
					                    </div>
					                </div>
					            </div>
					        </div>
					    </div>
					</form>

<script type="text/javascript">
	$(document).ready(function () {
        var droplist = $('#Studentabsent_courseid');
        droplist.change(function () {
            $.ajax({
                type: "POST",
                url: "Viewdropdown",
                data: {courseid: $('#Studentabsent_courseid option:selected').val()},
                dataType: "html",
                success: function (data) {
                    if (data == 1)
                    {
                        $('#Batch_daily').hide("slow");
                        $('#Batch_subject').show("slow");
                        $('#subject').show("slow");
                        $('#date').show("slow");
                    }
                    else
                    {
                        $('#Batch_subject').hide("slow");
                        $('#subject').hide("slow");
                        $('#Batch_subject').show("slow");
                        $('#date').show("slow");
                    }
                }
            });
        })
    });

    $(document).ready(function () {
        var droplist = $('#Studentabsent_subjectid');
        droplist.change(function () {
            $('#studentattendence tbody').empty();
            $.ajax({
                type: "POST",
                url: "Attendencelist_sub",
                data: {courseid: $('#Studentabsent_courseid option:selected').val(), batchid: $('#Studentabsent_batchid option:selected').val(), subjectid: $('#Studentabsent_subjectid option:selected').val()},
                dataType: "html",
                success: function (data) {
                    $('#studentattendence tbody').append(data);
                    $('#attendancediv').show("slow");
                }
            });
        })
    });

    $(document).ready(function () {
        var droplist = $('#Studentabsent_batchid');
        droplist.change(function () {
            $('#studentattendence tbody').empty();
            $.ajax({
                type: "POST",
                url: "Attendencelist",
                data: {courseid: $('#Studentabsent_courseid option:selected').val(), batchid: $('#Studentabsent_batchid option:selected').val(), subjectid: $('#Studentabsent_subjectid option:selected').val()},
                dataType: "html",
                success: function (data) {
                    $('#studentattendence tbody').append(data);
                    $('#attendancediv').show("slow");
                }
            });
        })
    });

    $(document).ready(function () {
        $('#checkall').click(function (event) {  //on click 
            if (this.checked) { // check select status
                $('.checkbox').each(function () { //loop through each checkbox
                    this.checked = true;  //select all checkboxes with class "checkbox1"               
                });
            } else {
                $('.checkbox').each(function () { //loop through each checkbox
                    this.checked = false; //deselect all checkboxes with class "checkbox1"                       
                });
            }
        });

    });
	
	$(document).ready(function () {
        $('#checkstatus').click(function (event) {  //on click 
            if (this.checked) { // check select status
                $('.checkbox1').each(function () { //loop through each checkbox
                    this.checked = true;  //select all checkboxes with class "checkbox1"               
                });
            } else {
                $('.checkbox1').each(function () { //loop through each checkbox
                    this.checked = false; //deselect all checkboxes with class "checkbox1"                       
                });
            }
        });

    });
	
	$(document).ready(function () {
        var droplist = $('#Studentabsent_date');
        droplist.change(function () {
            var date = $('#Studentabsent_date').val();
            var date = new Date(date).setHours(0,0,0,0);
			var now = ( new Date() ).setHours(0,0,0,0);
			if (date > now) {
				alert("Date must be less than or equal to current date");
				document.getElementById('Studentabsent_date').value='';
				return;
				}
			})
    });

    function saveabsent() {
        var date = $('#Studentabsent_date').val();
        var date = new Date(date).setHours(0, 0, 0, 0);
        var now = (new Date()).setHours(0, 0, 0, 0);
        if (date > now) {
            alert("Date must be less than or equal to current date");
            return;
        } else {
            var student = [];
            var studentabsent = [];
            var studentids = [];
            $('#studentattendence tbody tr').each(function (row, tr) {

              if ($(this).find(".checkbox").prop("checked")) {
                    //var amount = $(tr).find('td:eq(3)').text();
                    var studentid = $(tr).find('td:eq(0)').data('id');

                    var remark = $(tr).find('td:eq(4) input').val();

                    student.push(studentid);
                    student.push(remark);
                    if ($(this).find(".checkbox1").prop("checked")) {
                        student.push(1);
                    } else {
                        student.push(0);
                    }

                    studentids.push(studentid);
                } else {
                    var studentid = $(tr).find('td:eq(0)').data('id');
                    studentabsent.push(studentid);
                    studentids.push(studentid);
                }

            });
            var sendarray = JSON.stringify(student);
            var studentabsentarray = JSON.stringify(studentabsent);
            var studentids = JSON.stringify(studentids);
            $.ajax({
                type: "POST",
                url: "Conformationfordeletingattendance",
                data: {date: $('#Studentabsent_date').val(), studentids: studentids,subjectid: $('#Studentabsent_subjectid option:selected').val()},
                dataType: "html",
                success: function (data) {
                    if (data == "success") {
                        if (confirm("Student attendance already marked for this day.Are you sure you want to save over existing data?")) {
                            $.ajax({
                                type: "POST",
                                url: "Saveattendence",
                                data: {courseid: $('#Studentabsent_courseid option:selected').val(), batchid: $('#Studentabsent_batchid option:selected').val(), subjectid: $('#Studentabsent_subjectid option:selected').val(), sendarray: sendarray, date: $('#Studentabsent_date').val(), studentabsentarray: studentabsentarray},
                                dataType: "html",
                                success: function (data) {
                                    alert("Successfully saved");
                                    location.reload();

                                }
                            })
                        } else {
                            location.reload();
                        }
                    } else {
                        $.ajax({
                            type: "POST",
                            url: "Saveattendence",
                            data: {courseid: $('#Studentabsent_courseid option:selected').val(), batchid: $('#Studentabsent_batchid option:selected').val(), subjectid: $('#Studentabsent_subjectid option:selected').val(), sendarray: sendarray, date: $('#Studentabsent_date').val(), studentabsentarray: studentabsentarray},
                            dataType: "html",
                            success: function (data) {
                                alert("Successfully saved");
                                location.reload();
                            }
                        })
                    }
                }
            })
        }
    }

    $(document).ready(function () {
        var droplist = $('#Studentabsent_courseid1');
        droplist.change(function () {
            $.ajax({
                type: "POST",
                url: "Viewdropdown1",
                data: {courseid: $('#Studentabsent_courseid1 option:selected').val()},
                dataType: "html",
                success: function (data) {
                    if (data == 1)
                    {
                        $('#Batch_daily1').hide("slow");
                        $('#Batch_subject1').show("slow");
                        $('#subject1').show("slow");
                    }
                    else
                    {
                        $('#Batch_subject1').hide("slow");
                        $('#subject1').hide("slow");
                        $('#Batch_subject1').show("slow");
                    }
                }
            });
        })
    });
    function printDiv(divName) {
        var divToPrint = document.getElementById(divName);
        var popupWin = window.open('', '', 'width=300,height=300');
        popupWin.document.open();
        popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
        popupWin.document.close();
    }
</script>    
</script>
                
		</div> <!-- header_layout close -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/Student/attendence.blade.php ENDPATH**/ ?>