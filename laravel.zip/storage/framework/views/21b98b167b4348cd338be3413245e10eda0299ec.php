<?php $__env->startSection('content'); ?>

			<div class="content-wrapper">
                <div class="content"> <!-- content start -->

				    <div class="row">
				        <div class="col-lg-8">
				            <div class="row">
				                <div class="panel panel-white">
				                    <div class="panel-heading">
				                        <h6 class="panel-title">Student List</h6>
				                        <div class="heading-elements">
				                            <ul class="icons-list">
				                                <li><a data-action="collapse"></a></li>
				                                <li><a data-action="reload"></a></li>
				                                <li><a data-action="close"></a></li>
				                            </ul>
				                        </div>
				                        <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
				                    </div>
				                    <div class="panel-body">
					                    <div class="row">
									        <form id="assignsubject-form" action="" method="post">
									        	<div class="col-sm-3"> 
										            <select class="form-control" name="Student[courseid]" id="Student_courseid">
														<option value="">SelectCourse</option>
													</select>
													<div class="school_val_error" id="Student_courseid_em_" style="display:none"></div>
												</div>
										        <div class="col-sm-3"> 
										            <select class="form-control" name="Student[batchid]" id="Student_batchid">
														<option value="">SelectBatch</option>
													</select>
													<div class="school_val_error" id="Student_batchid_em_" style="display:none"></div>
												</div>
										        <div class="col-sm-3"> 
										        </div>
										        <div class="col-sm-3"> 
										            <input type="text" id="search" class="form-control" placeholder="Search...">
										        </div>
									        </form>
									    </div>
									</div>
									<div class="panel-body">
					                    <div class="dataTables_wrapper no-footer" id="DataTables_Table_0_wrapper">
					                    	<div class="grid-view table-responsive" id="student-grid">
								            	<table class="items">
													<thead>
														<tr>
															<th id="student-grid_c0">SL </th>
															<th id="student-grid_c1">Roll </th>
															<th id="student-grid_c2">ID </th>
															<th id="student-grid_c3">Name</th>
															<th id="student-grid_c3">Class</th>
															<th id="student-grid_c3">Group</th>
															<th id="student-grid_c4">Admission Date</th>
															<th class="button-column" id="student-grid_c7">Manage</th>
														</tr>
													</thead>
													<tbody>
														<?php ($i=0); ?>
														<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php ($i++); ?>
														<tr class="odd">
															<td width="5%"><?php echo e($i); ?></td>
															<td width="10%"><?php echo e($student->roll); ?></td>
															<td width="5%"><?php echo e($student->id); ?></td>
															<td width="20%"><?php echo e($student->name); ?></td>
															<td width="10%"><?php echo e($student->class); ?></td>
															<td width="10%"><?php echo e($student->group); ?></td>
															<td width="25%"><?php echo e($student->created_at); ?></td>
															<td width="15%">
																<a class="btn btn-sm btn-info" data-toggle="modal" data-target="#modal<?php echo e($student->id); ?>"><i class="fa fa-pencil"></i> </a>
																<form action="<?php echo e(action('StudentController@destroy', $student->id)); ?>" method="POST">
																	<?php echo e(csrf_field()); ?>

					          										<?php echo e(method_field('DELETE')); ?>

					          										<input type="hidden" name="id" value="<?php echo e($student->id); ?>">
					          										<button type="submit" class="btn btn-sm btn-danger delete-user"><i class="fa fa-trash"></i></button>
																</form>
																<!-- <a class="btn btn-sm btn-success" href="/sms"><i class="fa fa-envelope"></i> </a> -->
																<form action="<?php echo e(action('StudentController@sms', $student->id)); ?>" method="POST">
																	<?php echo e(csrf_field()); ?>


					          										<input type="hidden" name="id" value="<?php echo e($student->id); ?>">
					          										
					          										<button type="submit" class="btn btn-sm btn-success delete-user"><i class="fa fa-envelope"></i></button>
																</form>
															</td>
						<!-- Edit modal-->
						<div class="modal fade" id="modal<?php echo e($student->id); ?>" role="dialog">
			                <div class="modal-dialog">
			                        <!-- Modal content-->
			                    <div class="modal-content">
			                        <div class="modal-header bg-info">
			                            <button type="button" class="close" data-dismiss="modal">&times;</button>
			                        </div>
			                        <div class="modal-body">
			                            <form method="POST" action="<?php echo e(action('StudentController@update',$student)); ?>">
			                              	<input type="hidden" value="PUT" name="_method" >
			                        		<?php echo csrf_field(); ?>
					                        <div class="form-group row">
					                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

					                            <div class="col-md-6">
					                              	<input type="hidden" name="id" value="<?php echo e($student->id); ?>">
					                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($student->name); ?>" required autofocus>

					                                <?php if($errors->has('name')): ?>
					                                    <span class="invalid-feedback" role="alert">
					                                        <strong><?php echo e($errors->first('name')); ?></strong>
					                                    </span>
					                                <?php endif; ?>
					                            </div>
					                        </div>
			                        
					                        <div class="form-group row">
					                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Roll')); ?></label>

					                            <div class="col-md-6">
					                              	<input type="hidden" name="id" value="<?php echo e($student->id); ?>">
					                                <input id="" type="text" class="form-control<?php echo e($errors->has('roll') ? ' is-invalid' : ''); ?>" name="roll" value="<?php echo e($student->roll); ?>" required autofocus>

					                                <?php if($errors->has('roll')): ?>
					                                    <span class="invalid-feedback" role="alert">
					                                        <strong><?php echo e($errors->first('roll')); ?></strong>
					                                    </span>
					                                <?php endif; ?>
					                            </div>
					                        </div>
			                        
					                        <div class="form-group row">
					                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mobile')); ?></label>

					                            <div class="col-md-6">
					                              	<input type="hidden" name="id" value="<?php echo e($student->id); ?>">
					                                <input id="" type="text" class="form-control<?php echo e($errors->has('mobile') ? ' is-invalid' : ''); ?>" name="mobile" value="<?php echo e($student->mobile); ?>" required autofocus>

					                                <?php if($errors->has('mobile')): ?>
					                                    <span class="invalid-feedback" role="alert">
					                                        <strong><?php echo e($errors->first('mobile')); ?></strong>
					                                    </span>
					                                <?php endif; ?>
					                            </div>
					                        </div>
					                        <div class="form-group row mb-0">
					                        	<button type="submit" class="btn btn-info">
				                                    <?php echo e(__('Update')); ?>

				                                </button>
					                            <div class="col-md-6 offset-md-4">
					                                
					                            </div>
					                        </div>
			                    		</form>
			                        </div> <!-- End of modal-body -->
			                    </div>
			                </div>
			            </div> <!-- End of modal -->
														</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</tbody>
												</table>
												<div class="keys" style="display:none" title="/index.php/core/student/admin"><span>220</span><span>219</span><span>218</span><span>217</span></div>
											</div> <!-- end grid-view table-responsive -->
					                    </div>
					                </div>
				                </div>
				            </div>
    					</div>
				        <div class="col-lg-4">
				            <div class="panel panel-white">  
				                <div class="panel-heading">
				                    <h6 class="panel-title">Add Student</h6>
				                    <div class="heading-elements">
				                        <ul class="icons-list">
				                        	<li><a class="" href="#" data-action="collapse"></a></li>
				                        </ul>
				                    </div>
				                    <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
				                </div>
				                <div class="panel-body">
				                	<form action="<?php echo e(action('StudentController@store')); ?>" method="POST">
				                		<?php echo csrf_field(); ?>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="session" placeholder="Session" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="name" placeholder="Student Name" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="f_name" placeholder="Father's Name" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="m_name" placeholder="Mothers's Name" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="roll" placeholder="Roll" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="class" placeholder="Class" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="group" placeholder="Group" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="address" placeholder="Address" maxlength="40"> 
				                        </div>
				                        <div class="form-group">
				                            <input type="text" class="form-control" name="mobile" placeholder="Mobile" maxlength="40"> 
				                        </div>
				                        <input type="submit" name="add" class="btn btn-primary" value="ADD" />
				                    </form><br>
				            	</div>
				        	</div>
				    	</div>
					</div>
                </div>
            </div>
		</div> <!-- header_layout close -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/Student/index.blade.php ENDPATH**/ ?>