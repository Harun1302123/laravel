<?php $__env->startSection('content'); ?>

                <div class="content-wrapper">
                    <div class="content">
<div class="page-header">
    <div class="breadcrumb-line">
        <ul class="breadcrumb">
            <li><a href="#"><i class="icon-home2 position-left"></i>Home</a></li>
            <li><a href="#">Student</a></li>
            <li class="active">Student List</li>
        </ul>
        <ul class="breadcrumb-elements">
            <li><a href="/usermanual"><i class="icon-comment-discussion position-left"></i> Support</a></li>
        </ul>
        <a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a></div>
</div><br>
<div class="content">
    <div class="row">
        <form id="assignsubject-form" action="http://demowebsch.web-school.in/index.php/core/student/admin" method="post">        <div class="col-sm-3"> 
            <select class="form-control" name="Student[courseid]" id="Student_courseid">
<option value="">SelectCourse</option>
<option value="15">BSCIT ANIMATION</option>
<option value="16">Business Management</option>
</select><div class="school_val_error" id="Student_courseid_em_" style="display:none"></div>        </div>
        <div class="col-sm-3"> 
            <select class="form-control" name="Student[batchid]" id="Student_batchid">
<option value="">SelectBatch</option>
</select><div class="school_val_error" id="Student_batchid_em_" style="display:none"></div>        </div>
        <div class="col-sm-3"> 
        </div>
        <div class="col-sm-3"> 
            <input type="text"  id="search" class="form-control" placeholder="Search...">
        </div>
        </form>    </div><br>
    <div class="row">
        <div class="col-sm-12">

            <div class="grid-view table-responsive" id="student-grid">
<table class="items">
<thead>
<tr>
<th id="student-grid_c0">Sl.No.</th><th id="student-grid_c1"> Roll No.</th><th id="student-grid_c2">Admission No.</th><th id="student-grid_c3">Student Name</th><th id="student-grid_c4">Admission Date</th><th id="student-grid_c5">Course</th><th id="student-grid_c6">Batch</th><th class="button-column" id="student-grid_c7">Manage</th></tr>
</thead>
<tbody>
<tr class="odd">
<td width="5%">1</td><td>50</td><td>DEM4</td><td width="30%">Mohammed Mohsin Khan</td><td>2016-06-03</td><td width="10%">BSCIT ANIMATION</td><td width="10%">B</td><td width="10%"> <a class="glyphicon glyphicon-eye-open" title="" href="/index.php/core/student/view/id/220"><img src="" alt="" /></a> <a class="glyphicon glyphicon-remove" title="" href="/index.php/core/student/delete/id/220"><img src="" alt="" /></a></td></tr>
<tr class="even">
<td width="5%">2</td><td>Roll123</td><td>DEM3</td><td width="30%">Reem Noor </td><td>2018-06-19</td><td width="10%">Business Management</td><td width="10%">A</td><td width="10%"> <a class="glyphicon glyphicon-eye-open" title="" href="/index.php/core/student/view/id/219"><img src="" alt="" /></a> <a class="glyphicon glyphicon-remove" title="" href="/index.php/core/student/delete/id/219"><img src="" alt="" /></a></td></tr>
<tr class="odd">
<td width="5%">3</td><td>5005</td><td>DEM2</td><td width="30%">Nader Mohammed </td><td>2018-06-01</td><td width="10%">BSCIT ANIMATION</td><td width="10%">A</td><td width="10%"> <a class="glyphicon glyphicon-eye-open" title="" href="/index.php/core/student/view/id/218"><img src="" alt="" /></a> <a class="glyphicon glyphicon-remove" title="" href="/index.php/core/student/delete/id/218"><img src="" alt="" /></a></td></tr>
<tr class="even">
<td width="5%">4</td><td>&nbsp;</td><td>DEM1</td><td width="30%">John Steve </td><td>1969-12-31</td><td width="10%">Business Management</td><td width="10%">B</td><td width="10%"> <a class="glyphicon glyphicon-eye-open" title="" href="/index.php/core/student/view/id/217"><img src="" alt="" /></a> </td></tr>
</tbody>
</table>
<div class="keys" style="display:none" title="http://demowebsch.web-school.in/index.php/core/student/admin"><span>220</span><span>219</span><span>218</span><span>217</span></div>
</div>        </div>
    </div>
</div>
<script>

    $("input").keyup(function () {

        $('#student-grid').yiiGridView('update', {
            data: {search: $('#search').val()}
        });
        return false;

    });

    $('#Student_batchid').change(function () {
        var values = $('#Student_courseid option:selected').text() + "," + $('#Student_batchid option:selected').text();
        $('#student-grid').yiiGridView('update', {
            data: {search: values}
        });
        return false;

    });

</script>
	

		
                    </div>
                                        <div class="navbar navbar-default navbar-sm navbar-fixed-bottom">
                        <ul class="nav navbar-nav no-border visible-xs-block">
                            <li>
                                <a data-target="#navbar-second" data-toggle="collapse" class="text-center collapsed">
                                    <i class="icon-circle-up2"></i>
                                </a>
                            </li>
                        </ul>
                        <div id="navbar-second" class="navbar-collapse collapse">
                            <div class="navbar-text">
                                &copy; 2018.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
/*<![CDATA[*/
jQuery(function($) {
jQuery('body').on('change','#Student_courseid',function(){jQuery.ajax({'type':'POST','url':'/index.php/core/Student/Fetchbatchupdate','cache':false,'data':jQuery(this).parents("form").serialize(),'success':function(html){jQuery("#Student_batchid").html(html)}});return false;});
jQuery('#assignsubject-form').yiiactiveform({'validateOnChange':false,'validateOnSubmit':true,'attributes':[{'id':'Student_courseid','inputID':'Student_courseid','errorID':'Student_courseid_em_','model':'Student','name':'courseid','enableAjaxValidation':true},{'id':'Student_batchid','inputID':'Student_batchid','errorID':'Student_batchid_em_','model':'Student','name':'batchid','enableAjaxValidation':true}],'errorCss':'error'});
jQuery(document).on('click','#student-grid a.glyphicon.glyphicon-remove',function() {
	if(!confirm('Are you sure you want to delete this item?')) return false;
	var th = this,
		afterDelete = function(){};
	jQuery('#student-grid').yiiGridView('update', {
		type: 'POST',
		url: jQuery(this).attr('href'),
		success: function(data) {
			jQuery('#student-grid').yiiGridView('update');
			afterDelete(th, true, data);
		},
		error: function(XHR) {
			return afterDelete(th, false, XHR);
		}
	});
	return false;
});
jQuery('#student-grid').yiiGridView({'ajaxUpdate':['1','student-grid'],'ajaxVar':'ajax','pagerClass':'pager','loadingClass':'grid-view-loading','filterClass':'filters','tableClass':'items','selectableRows':1,'enableHistory':false,'updateSelector':'{page}, {sort}','filterSelector':'{filter}','pageVar':'Student_page'});
jQuery('#user').autocomplete({'minLength':'1','select':function( event, ui ) {
                                     $("#hidden-field").val(ui.item.value);                
                                     return true;  
                                     },'source':'http://demowebsch.web-school.in/index.php/core/student/admin/index.php/core/institution/autocompleteUsers'});
});
/*]]>*/
</script>


</div> <!-- header_layout close -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/Student/store.blade.php ENDPATH**/ ?>