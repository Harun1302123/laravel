<!DOCTYPE html>
<html>
<head>
  <title>data</title>
  <!--  bootstrap 4 link  -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"> 
  <!--  data table link  -->
  <link rel="stylesheet" href="http://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <!--  font-awesome link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!--  style -->
  <link rel="stylesheet" href="../css/style.css">
  <!--  js link  -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
  <!--  data table js link  -->
  <script src="http://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript">
    $(document).ready( function () {
        $('#myTable').DataTable();
    } );
  </script>
</head>
<body>
	<table id="myTable">
		<tr>
			<td style="border: 1px solid;">Id</td>
			<td style="border: 1px solid;">Name</td>
			<td style="border: 1px solid;">Address</td>
		</tr>
		<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td style="border: 1px solid;"><?php echo e($data->id); ?></td>
			<td style="border: 1px solid;"><?php echo e($data->name); ?></td>
			<td style="border: 1px solid;"><?php echo e($data->address); ?></td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td>Add Data</td>
			<td>
            <!-- Trigger the modal with a button -->
	          <a class="btn btn-info" href="#" data-toggle="modal" data-target="#myModal">+</a>
	        </td>
		</tr>
	</table>


	

	<!-- Modal delete -->
	  <div class="modal fade" id="myModal_1" role="dialog">
	    <div class="modal-dialog">
	    
	      <!-- Modal content-->
	        
	      
	    </div>
	  </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\school\resources\views/school.blade.php ENDPATH**/ ?>