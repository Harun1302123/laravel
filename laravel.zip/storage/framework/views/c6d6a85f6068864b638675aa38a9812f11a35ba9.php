<?php $__env->startSection('content'); ?>



            <div class="content-wrapper">
                <div class="content">
					<div class="page-header">
					    <div class="row">
					        <div class="page-header-content">
					            <div class="row">
					                <div class="col-lg-3">
					                    <div class="panel bg-warning-300" onclick="location.href = '/index.php/core/student/admin';" style="cursor:pointer;">
					                        <div class="panel-body">
					                            <div class="row">
                                                	<div class="col-lg-6" >
                                                		<i class="icon-graduation" style="font-size:60px"></i>
                                                	</div>
					                                <div class="col-lg-6">
					                                    <h2 class="no-margin" style="font-size:35px">4</h2>
					                                </div> 
                            					</div>
					                            &emsp;&emsp;&emsp;
					                            TOTAL STUDENTS               
					                        </div>
					                    </div>
					                </div>
					                <div class="col-lg-3">
					                    <div class="panel bg-teal-300" onclick="location.href = '/index.php/core/employeedetails/admin';" style="cursor:pointer;">
					                        <div class="panel-body">
					                            <div class="row">
					                                <div class="col-lg-6">
					                                	<i class="icon-user-tie"  style="font-size:60px"></i>
					                                </div>
					                                <div class="col-lg-6">
					                                    <h2 class="no-margin" style="font-size:35px"> 2</h2>
					                                </div> 
					                            </div>  
					                            &emsp;&emsp;&emsp;
					                            TOTAL EMPLOYEES 
					                        </div>
					                    </div>
					                </div>
					                <div class="col-lg-3">
					                    <div class="panel bg-pink-300" onclick="location.href = '/course/create';" style="cursor:pointer;">
					                        <div class="panel-body">
					                            <div class="row">
					                                <div class="col-lg-6" >
					                                	<i class="icon-book3" style="font-size:60px"></i>
					                                </div>
					                                <div class="col-lg-6">
					                                    <h2 class="no-margin" style="font-size:35px">30</h2>
					                                </div> 
					                            </div>
					                            &emsp;&emsp;&emsp;&emsp;&emsp;
					                            TOTAL COURSE
					                        </div>
					                    </div>
					                </div>
					                <div class="col-lg-3">
					                    <div class="panel bg-purple-300" onclick="location.href = '/batch/create';" style="cursor:pointer;">
					                        <div class="panel-body">
					                            <div class="row">
					                                <div class="col-lg-6" >
					                                	<i class="icon-file-text" style="font-size:60px"></i>
					                                </div>
					                                <div class="col-lg-6">
					                                    <h2 class="no-margin" style="font-size:35px">67                                    
					                                    </h2>
					                                </div> 
					                            </div>
					                            &emsp;&emsp;&emsp;&emsp;&emsp;
					                            TOTAL BATCH                        
					                        </div>
					                    </div>
					                </div>
					            </div>
					        </div>
						    <div class="navbar navbar-default navbar-component navbar-xs">
						        <ul class="nav navbar-nav visible-xs-block">
						            <li class="full-width text-center"><a data-target="#navbar-filter" data-toggle="collapse"><i class="icon-menu7"></i></a></li>
						        </ul>
						        <div id="navbar-filter" class="navbar-collapse collapse">
						            <ul class="nav navbar-nav element-active-slate-400">
						                <li class="active"><a data-toggle="tab" href="#activity"><i class="icon-menu7 position-left"></i> Activity</a></li>
						                <li><a data-toggle="tab" href="#schedule"><i class="icon-calendar3 position-left"></i> Schedule </a></li>
						                <li><a data-toggle="tab" href="#fees_tab" onclick="feegraph()"><i class="glyphicon glyphicon-signal position-left"></i> Fee reports </a></li>
						            </ul>
						            <div class="navbar-right">
						                <ul class="nav navbar-nav">
						                    <li class="dropdown">
						                        <a data-toggle="dropdown" class="dropdown-toggle" href="#"><i class="icon-grid"></i> <span class="visible-xs-inline-block position-right"> Options</span> 
						                            <span class="caret"></span></a>
						                        <ul class="dropdown-menu dropdown-menu-right" style="width: 260px">
						                            <div class="category-content">
						                                <div class="row">
						                                    <button type="button" onClick="location = '/student/create'" class="btn bg-teal-400 btn-block btn-float btn-float-lg">
						                                    	<i class="icon-users"></i> <span>Student Admission</span>
						                                    </button>
						                                    <button type="button"  onClick="location = '/assignment/create'" class="btn bg-purple-300 btn-block btn-float btn-float-lg">
						                                    	<i class="icon-book3"></i> <span>Add Assignment</span>
						                                    </button>
						                                </div>
						                                <div class="col-xs-6">
						                                    <button type="button" onClick="location = '/employeedetails/create'" class="btn bg-warning-400 btn-block btn-float btn-float-lg">
						                                        <i class="icon-user-tie"></i> <span>Add Employee</span>
						                                    </button>
						                                    <button type="button" onClick="location = '/feesallocation/collection'" class="btn bg-blue btn-block btn-float btn-float-lg">
						                                        <i class="icon-cash3"></i> <span>Fee Collection</span>
						                                    </button>
						                                </div>
						                            </div>
						                    	</ul>
						                    </li>
						                    <li><a href="/usermanual"><i class="icon-stack-text position-left"  tooltip="usermanual"></i>Support</a></li>
						                </ul>
						            </div>
						        </div>
						    </div>
						</div>
					</div>
				</div>
				<div class="content">
				    <div class="row">
				        <div class="col-lg-8">
				            <div class="row">
				                <div class="tabbable">
				                    <div class="tab-content">
                                        <div class="tab-pane fade active in" id="activity">
				                            <div class="panel panel-flat">
				                                <div class="panel-heading">
				                                    <h6 class="panel-title">Daily Attendance Overview</h6>
				                                    <div class="heading-elements">
				                                        <ul class="icons-list">
				                                            <li><a data-action="collapse"></a></li>
				                                            <li><a data-action="reload"></a></li>
				                                        </ul>
				                                    </div>
				                                    <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
				                                </div>
				                                <div class="panel-body">                            
				                                    <div class="position-relative">
				                                        <span class='one'>
				                                            &nbsp;&nbsp;&nbsp;</span>
				                                        &nbsp;Employee  &nbsp;&nbsp;&nbsp;
				                                        <span class='two'>&nbsp;&nbsp;&nbsp;</span>
				                                        &nbsp;Student 
				                                        <canvas id="atten" style="height:50px;"></canvas>
				                                    </div>
				                                </div>
				                            </div>
				                        </div>

					                    <div class="tab-pane fade" id="schedule">   
					                        <div class="panel panel-white"> 
					                            <div class="panel-heading">
					                                <h6 class="panel-title">Calendar</h6>
					                                <div class="heading-elements">
					                                    <ul class="icons-list">
					                                        <li><a data-action="collapse"></a></li>
					                                        <li><a data-action="reload"></a></li>
					                                    </ul>
					                                </div>
					                                <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
					                            </div>
					                            <div class="panel-body">
					                                <div id='calendar'></div>
					                            </div>
					                        </div>
					                    </div>

				                        <div class="tab-pane fade" id="fees_tab">
				                            <div class="panel panel-flat">
				                                <div class="panel-heading">
				                                    <h6 class="panel-title">Fee reports</h6>
				                                    <div class="heading-elements">
				                                        <ul class="icons-list">
				                                            <li><a data-action="collapse"></a></li>
				                                            <li><a data-action="reload"></a></li>
				                                        </ul>
				                                    </div>
				                                    <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
				                                </div>

				                                <div class="panel-body" id="">
				                                    <div class="col-sm-11">
				                                        <div id="feereport_graph1" allign="center">
				                                            <span class='fone'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;Total
				                                            <span class='ftwo'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;Collected
				                                            <span class='fthree'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;&nbsp;Remaining
				                                        </div><br/>
				                                        <div id="loader"  style="display:none;"></div>
				                                        <canvas id="fee" style="height:150;width:50%;"></canvas>
				                                        <div id="feereport_graph">

				                                        </div>                                  
				                                    </div>
				                                </div>

				                            </div>
				                        </div>
				                    </div>
				                </div> 
				            </div>
				            <div class="row">
				                <div class="panel panel-white">
				                    <div class="panel-heading">
				                        <h6 class="panel-title">Task manager</h6>
				                        <div class="heading-elements">
				                            <ul class="icons-list">
				                                <li><a data-action="collapse"></a></li>
				                                <li><a data-action="reload"></a></li>
				                                <li><a data-action="close"></a></li>
				                            </ul>
				                        </div>
				                        <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
				                    </div>
				                    <div class="dataTables_wrapper no-footer" id="DataTables_Table_0_wrapper">
				                    	<div class="datatable-scroll-lg">
				                            <table aria-describedby="DataTables_Table_0_info" role="grid" id="DataTables_Table_0" class="table tasks-list table-lg dataTable no-footer" width="100%">
				                                <thead>
				                                    <tr role="row">
				                                        <th style="width: 5%;" colspan="1" rowspan="1">#</th>
				                                        <th style="width: 40%;" colspan="1" rowspan="1"> Description</th>
				                                        <th style="width: 10%;" colspan="1" rowspan="1">Priority</th>
				                                        <th style="width: 15%;" colspan="1" rowspan="1">Task Date</th>
				                                        <th style="width: 15%;" colspan="1" rowspan="1">Status</th>
				                                    </tr>
				                                </thead>
				                                <tbody>
				                                	<tr class="odd" role="row">
				                                        <td class="sorting_1">1</td>
				                                        <td>
				                                            <div class="text-semibold">
				                                            	<a href="/taskmanager/view/id/37">Demo</a>
				                                            </div>
				                                        </td>
				                                        <td>
				                                            <div class="btn-group">
				                                            	<a href="#" class="label label-danger dropdown-toggle" data-toggle="dropdown">Highest</a>
				                                            </div>
				                                        </td>
				                                        <td>
				                                            <div class="input-group input-group-transparent">
				                                                <div class="input-group-addon"><i class="icon-calendar2 position-left"></i></div>
				                                                <input id="dp1446022246633" class="form-control datepicker hasDatepicker" value="2019-May-28" type="text">
				                                            </div>
				                                        </td>

				                                        <td>
				                                            <div class="btn-group">
				                                                <a href="#" class="label label-info dropdown-toggle" data-toggle="dropdown">
				                                                   Open
				                                                </a>
				                                            </div>
				                                        </td>
				                                    </tr>
				                                    <tr class="odd" role="row">
				                                        <td class="sorting_1">2</td>
				                                        <td>
				                                            <div class="text-semibold">
				                                            	<a href="taskmanager/view/id/34">123</a>
				                                            </div>
				                                        </td>
				                                        <td>
				                                            <div class="btn-group">
				                                            	<a href="#" class="label label-success dropdown-toggle" data-toggle="dropdown"> Low </a>
				                                            </div>
				                                        </td>
				                                        <td>
				                                            <div class="input-group input-group-transparent">
				                                                <div class="input-group-addon">
				                                                	<i class="icon-calendar2 position-left"></i>
				                                                </div>
				                                                <input id="dp1446022246633" class="form-control datepicker hasDatepicker" value="2019-May-09" type="text">
				                                            </div>
				                                        </td>
				                                        <td>
				                                            <div class="btn-group">
				                                                <a href="#" class="label label-info dropdown-toggle" data-toggle="dropdown">
				                                                   Open
				                                                </a>
				                                            </div>
				                                        </td>
				                                    </tr>                                              
				                                </tbody>
				                            </table>
				                        </div>
				                    </div>
				                </div>
				            </div>
    					</div>
				        <div class="col-lg-4">
				            <div class="panel panel-flat">
				                <!-- Tabs -->
				                <ul class="nav nav-lg nav-tabs nav-justified no-margin no-border-radius bg-indigo-400 border-top border-top-indigo-300">
				                    <li class="active">
				                        <a href="#messages-tue" class="text-size-small text-uppercase" data-toggle="tab">
				                            News Feeds
				                        </a>
				                    </li>
				                </ul>
				                <!-- Tabs content -->
				                <div class="tab-content">
				                    <div class="tab-pane active fade in has-padding" id="messages-tue">
				                        <ul class="media-list">
				                        	<li class="media">
				                                <div class="media-left">
				                                	<img src="/banner/5.jpg" class="img-circle img-xs" alt="">
				                                	<span class="badge bg-danger-400 media-badge">S</span>
				                                </div>

				                                <div class="media-body">
				                                    <a href="/index.php/core/newsfeeds/view/id/5">
				                                        School reopens on June 4 <span class="media-annotation pull-right"><i class="glyphicon glyphicon-calendar"></i> 01-06-2018</span>
				                                    </a>
				                                    <span class="display-block text-muted">Majority private state-r</span>
				                                </div>
				                            </li>
				                        </ul>
				                    </div>
				                </div>
				            </div>
				        </div>
				        <div class="col-md-4">
				            <div class="panel panel-flat ">
				                <div class="panel-heading">
				                	<h6 class="panel-title">
				                		<center>Birthday Today</center>
				                		<a class="heading-elements-toggle">
				                			<i class="icon-more"></i>
				                		</a>
				                	</h6>
				                </div>
				                <div class="table-responsive">
				                    <table class="table table-xlg text-nowrap">
				                        <tbody>
				                            <tr class="col-md-12">
				                                <td class="col-md-3">
				                                    <div class="media-left media-middle">
				                                        <a href="/student/Studentbirthday" class="text-pink-400"><i class="fa fa-graduation-cap" style="font-size:38px; "></i>
				                                        </a>
				                                        <b><center>0</center></b>
				                                        <small class="text-muted display-block no-margin">Students</small>
				                                    </div>
				                                </td>
				                                <td class="col-md-2">
				                                    <a href="#" style="color:#9A9A9A" class="text-indigo-400"><i class="fa fa-birthday-cake" style="font-size:38px;"></i></a>
				                                </td>
				                                <td class="col-md-3">
				                                    <div class="media-left media-middle">
				                                        <a href="employeemaster/employeebirthday"><i class="icon-users display-inline-block text-info" style="color:#4482E8;font-size:37px;top:2px;"></i></a>
				                                        <b><center>0</center></b><small class="text-muted display-block no-margin">Employee</small>
				                                    </div>
				                                </td>
				                            </tr>
				                        </tbody>
				                    </table>    
				                </div>
				            </div>
				        </div>
				        <div class="col-lg-4">
				            <div id="feescollecteddaily">
				            	<div class="panel panel-flat">
					                <div class="panel-heading">
					                    <h6 class="panel-title">Fee collection of the day</h6>
					                    <div class="heading-elements">
					                    <span class="heading-text"><i class="icon-history text-warning position-left"></i>14-06-2019</span>
					                    </div>
					                </div>

					                <!-- Numbers -->
					                <div class="container-fluid">
					                    <div class="row text-center">
					                        <div class="col-md-4">
					                            <div class="content-group">
					                                <h6 class="text-semibold no-margin"><i class="icon-cash3 position-left text-slate"></i>0</h6>
					                                <span class="text-muted text-size-small">Amount</span>
					                            </div>
					                        </div>

					                        <div class="col-md-4">
					                            <div class="content-group">
					                                <h6 class="text-semibold no-margin"><i class="icon-cash3 position-left text-slate"></i> 0</h6>
					                                <span class="text-muted text-size-small">Discount</span>
					                            </div>
					                        </div>

					                        <div class="col-md-4">
					                            <div class="content-group">
					                                <h6 class="text-semibold no-margin"><i class="icon-cash3 position-left text-slate"></i> 0</h6>
					                                <span class="text-muted text-size-small">Fine</span>
					                            </div>
					                        </div>
					                    </div>
					                </div>
					            </div>
				            </div>
				        </div>
					</div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/attdence.blade.php ENDPATH**/ ?>