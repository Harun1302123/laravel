<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" type="text/css" href="http://demowebsch.web-school.in/assets/1d179a7/css/styles.css" />
        <link rel="stylesheet" type="text/css" href="http://demowebsch.web-school.in/assets/1d179a7/css/styles.css" />
<link rel="stylesheet" type="text/css" href="http://demowebsch.web-school.in/assets/9f14d2be/jui/css/base/jquery-ui.css" />
<script type="text/javascript" src="http://demowebsch.web-school.in/assets/9f14d2be/jquery.js"></script>
<script type="text/javascript" src="http://demowebsch.web-school.in/assets/1d179a7/js/Chart.js"></script>
<title>School ERP</title>
        <!-- Global stylesheets -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
        <link href="http://demowebsch.web-school.in/css/assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/assets/css/minified/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/assets/css/minified/core.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/assets/css/minified/components.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/assets/css/minified/colors.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="http://demowebsch.web-school.in/css/assets/css/fullcalendar.css" rel="stylesheet" type="text/css">
        <link href="http://demowebsch.web-school.in/css/assets/css/fullcalendar.print.css" rel="stylesheet" type="text/css" media="print">
        <link href="http://demowebsch.web-school.in/css/assets/css/glyph.css" rel="stylesheet" type="text/css">
        <link href="http://demowebsch.web-school.in/css/assets/css/icons/fontawesome/styles.min.css" rel="stylesheet" type="text/css">

       
        <!-- Load jQuery -->
        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/core/libraries/jquery.min.js"></script>

        <!-- Load Moment extension -->
        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/plugins/ui/moment/moment.min.js"></script>

        <!-- Load plugin -->
        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/plugins/pagination/datepaginator.min.js"></script>
        <!-- Load base -->
        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/plugins/pickers/pickadate/picker.js"></script>

        <!-- Load date picker -->
        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/plugins/pickers/pickadate/picker.date.js"></script>
        <!-- Load time picker -->
        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/plugins/pickers/pickadate/picker.time.js"></script>
        <script type="text/javascript" src="http://demowebsch.web-school.in/js/custom.js"></script>
        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/plugins/notifications/pnotify.min.js"></script>

        <script type="text/javascript" src="http://demowebsch.web-school.in/css/assets/js/pages/components_notifications_pnotify.js"></script>

    </head>
    <body class="pace-done">
        <div class="navbar navbar-default header-highlight">
            <div class="navbar-header">
                <a class="navbar-brand" href="#"><img src="/images/logo-1t.png" alt=""></a>
                <ul class="nav navbar-nav visible-xs-block">
                    <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
                    <li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
                </ul>
            </div>

            <div class="navbar-collapse collapse" id="navbar-mobile">
                <ul class="nav navbar-nav">
                    <li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>

                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-git-compare"></i>
                            <span class="visible-xs-inline-block position-right">Updates</span>
                            <span class="badge bg-warning-400">!</span>
                        </a>
                        <div class="dropdown-menu dropdown-content">
                            <div class="dropdown-content-heading">Updates</div>
                            <ul class="media-list dropdown-content-body width-350">
                                <li class="media">
                                    <div class="media-left">
                                        <a href="#" class="btn border-brown-800 text-brown-800 btn-flat btn-rounded btn-icon btn-sm"><i class="icon-pen"></i></a>
                                    </div>
                                    <div class="media-body">
                                       <a href="/index.php/leave/leaveapplication/approve"><font color="#4E342E">Leave Approvals</font></a><br> 
                                         <div class="media-annotation"> You have 2 pending leave approval(s)</div>
                                    </div>
                                </li> 
                            </ul>
                        </div>
                    </li>
                </ul>
                                    <p class="navbar-text"><span class="label bg-info">Academic Year: ( 2006 - 2017 )</span></p>
                                <ul class="nav navbar-nav navbar-right">
                                            <form class="navbar-form navbar-left" action="/index.php/core/institution/search" target="_blank" method="POST">
                            <div class="form-group">
                                <input placeholder="Search..." class="form-control" id="user" type="text" value="" name="user" /><input id="hidden-field" name="output" type="hidden" value="" />                            </div>
                            <button type="submit" class="btn btn-default" onclick="return autocompletesearch()"><i class="icon-search4"></i></button>
                        </form>
                                        <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-bubbles4"></i>
                            <span class="visible-xs-inline-block position-right">Messages</span>
                                                        <span class="badge bg-warning-400" id="envelope">0</span>
                        </a>
                        <div class="dropdown-menu dropdown-content width-350">
                            <div class="dropdown-content-heading"> Messages </div>
                            <ul class="media-list dropdown-content-body">
                                                            </ul>
                            <div class="dropdown-content-footer">
                                                                    <a href="/index.php/core/email/email" data-popup="tooltip" title="All messages"><i class="icon-menu display-block"></i></a>
                                                            </div>
                        </div>
                    </li>
                                            <li class="dropdown dropdown-user">
                                                            <a class="dropdown-toggle" data-toggle="dropdown">
                                    <img src="/banner/01062018035544.jpg" alt="">
                                    <span>Andre  Rudolph</span>
                                    <i class="caret"></i>
                                </a>
                                                        <ul class="dropdown-menu">
                                                                    <li><a href="/index.php/core/institution/profile"><i class="icon-user"></i>Profile</a></li>
                                                                <li><a href="/index.php/user/logout" onclick="signOut();"><i class="icon-switch2"></i>Log Out</a></li>

                            </ul>
                        </li>
                                        </ul>
            </div>
        </div>
    <?php echo $__env->yieldContent('content'); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/layouts/app_layouts.blade.php ENDPATH**/ ?>